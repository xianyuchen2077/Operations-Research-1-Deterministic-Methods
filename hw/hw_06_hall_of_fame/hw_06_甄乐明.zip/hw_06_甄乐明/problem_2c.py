import pandas as pd
from gurobipy import Model, GRB
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
excel_path = os.path.join(BASE_DIR, "problem_2b.xlsx")
input_sheet = "Sheet1"              
output_sheet = "Solution_Gurobi"


# 1.DataReading
df = pd.read_excel(excel_path, sheet_name=input_sheet, header=None)
cell = lambda r, c: df.iat[r, c]    

vendors = [cell(2,1), cell(3,1), cell(4,1)]
unit_cost= {cell(i,1): cell(i,4) for i in [2,3,4]}
delivery_cost = {cell(i,1): cell(i,5) for i in [2,3,4]}

capacity      = {1: 500, 2: 900, 3: 400}
min_order     = cell(6,2)
total_units_needed  = cell(8,2)

# 2.Model

m = Model("ComputerPurchase")

x = {i: m.addVar(vtype=GRB.INTEGER, name=f"x_{i}") for i in vendors}
y = {i: m.addVar(vtype=GRB.BINARY,  name=f"y_{i}") for i in vendors}

m.setObjective(
    sum(unit_cost[i] * x[i] + delivery_cost[i] * y[i] for i in vendors),
    GRB.MINIMIZE
)

m.addConstr(sum(x[i] for i in vendors) == total_units_needed)
for i in vendors:
    m.addConstr(x[i] <= capacity[i] * y[i],  name=f"Cap_{i}")
    m.addConstr(x[i] >= min_order  * y[i],  name=f"Min_{i}")

m.optimize()

# 3.Results
if m.status == GRB.OPTIMAL:
    result_rows = [
        ["Status", "Optimal"],
        ["Total Cost", m.ObjVal],
        ["", ""],
        ["Vendor", "Computers Purchased (x_i)"],
    ]
    
    for i in vendors:
        result_rows.append([f"Vendor {i}", x[i].X])

    result_rows.append(["", ""])
    
    result_rows.append(["Vendor", "Vendor Used (y_i)"])
    for i in vendors:
        result_rows.append([f"Vendor {i}", int(y[i].X)])

else:
    result_rows = [["Status", "Not Optimal"]]

results_df = pd.DataFrame(result_rows, columns=["Results", "Value"])

with pd.ExcelWriter(
        excel_path, engine="openpyxl", mode="a", if_sheet_exists="replace") as writer:
    results_df.to_excel(writer, sheet_name=output_sheet, index=False)