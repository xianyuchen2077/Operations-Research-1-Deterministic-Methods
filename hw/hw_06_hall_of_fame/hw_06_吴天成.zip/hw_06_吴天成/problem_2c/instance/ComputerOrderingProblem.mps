* Signature: 0x3728ce8e3b754a5b
NAME Computer_Ordering_Optimization
ROWS
 N  OBJ
 G  Total_Demand
 G  Min_Order_Vendor_1
 L  Max_Order_Vendor_1
 G  Min_Order_Vendor_2
 L  Max_Order_Vendor_2
 G  Min_Order_Vendor_3
 L  Max_Order_Vendor_3
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    order_Vendor_1  OBJ       5000
    order_Vendor_1  Min_Order_Vendor_1  -200
    order_Vendor_1  Max_Order_Vendor_1  -500
    quantity_Vendor_1  OBJ       500
    quantity_Vendor_1  Total_Demand  1
    quantity_Vendor_1  Min_Order_Vendor_1  1
    quantity_Vendor_1  Max_Order_Vendor_1  1
    order_Vendor_2  OBJ       4000
    order_Vendor_2  Min_Order_Vendor_2  -200
    order_Vendor_2  Max_Order_Vendor_2  -900
    quantity_Vendor_2  OBJ       350
    quantity_Vendor_2  Total_Demand  1
    quantity_Vendor_2  Min_Order_Vendor_2  1
    quantity_Vendor_2  Max_Order_Vendor_2  1
    order_Vendor_3  OBJ       6000
    order_Vendor_3  Min_Order_Vendor_3  -200
    order_Vendor_3  Max_Order_Vendor_3  -400
    quantity_Vendor_3  OBJ       250
    quantity_Vendor_3  Total_Demand  1
    quantity_Vendor_3  Min_Order_Vendor_3  1
    quantity_Vendor_3  Max_Order_Vendor_3  1
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      Total_Demand  1100
BOUNDS
 BV BND1      order_Vendor_1
 UP BND1      quantity_Vendor_1  500
 BV BND1      order_Vendor_2
 UP BND1      quantity_Vendor_2  900
 BV BND1      order_Vendor_3
 UP BND1      quantity_Vendor_3  400
ENDATA
