# -*- coding: utf-8 -*-
"""
model
"""

import gurobipy as gp
from gurobipy import GRB
import constant


def create_model(data):
    """
    Create and solve the integer programming model for computer ordering
    
    Args:
        data (dict): Dictionary containing all problem data
        
    Returns:
        tuple: (model, order_vars, quantity_vars) if successful, (None, None, None) otherwise
    """
    try:
        # data
        vendor_names = data["vendor_names"]
        unit_prices = data["unit_prices"]
        delivery_charges = data["delivery_charges"]
        max_supplies = data["max_supplies"]
        min_order = data["min_order"]
        total_demand = data["total_demand"]
        num_vendors = data["num_vendors"]
        
        # Create model
        model = gp.Model(constant.MODEL_NAME)
        model.setParam('OutputFlag', 0)  # Suppress Gurobi output
        
        # Create variables
        # Binary decision variables: whether to order from each vendor
        order_vars = {}
        # Integer decision variables: order quantity from each vendor
        quantity_vars = {}
        
        for i in range(num_vendors):
            # Binary variable for ordering decision (0 or 1)
            order_vars[i] = model.addVar(
                vtype=GRB.BINARY,
                name=f"{constant.VAR_ORDER_PREFIX}{vendor_names[i].replace(' ', '_')}"
            )
            
            # Integer variable for order quantity
            quantity_vars[i] = model.addVar(
                vtype=GRB.INTEGER,
                lb=0,  # Lower bound is 0
                ub=max_supplies[i],  # Upper bound is maximum supply
                name=f"{constant.VAR_QUANTITY_PREFIX}{vendor_names[i].replace(' ', '_')}"
            )
        
        # Integrate variables
        model.update()
        
        # Set objective function: minimize total cost
        # Total cost = sum(unit_price * quantity) + sum(delivery_charge * order_decision)
        unit_cost_expr = gp.quicksum(unit_prices[i] * quantity_vars[i] for i in range(num_vendors))
        delivery_cost_expr = gp.quicksum(delivery_charges[i] * order_vars[i] for i in range(num_vendors))
        total_cost_expr = unit_cost_expr + delivery_cost_expr
        
        model.setObjective(total_cost_expr, GRB.MINIMIZE)
        
        # Add constraints
        
        # 1. Total demand constraint: sum of quantities must meet or exceed total demand
        model.addConstr(
            gp.quicksum(quantity_vars[i] for i in range(num_vendors)) >= total_demand,
            name="Total_Demand"
        )
        
        # 2. If we order from a vendor, quantity must be at least min_order
        #    If we don't order, quantity must be 0
        for i in range(num_vendors):
            # If order_vars[i] = 1, then quantity_vars[i] >= min_order
            # If order_vars[i] = 0, then quantity_vars[i] = 0
            model.addConstr(
                quantity_vars[i] >= min_order * order_vars[i],
                name=f"Min_Order_{vendor_names[i].replace(' ', '_')}"
            )
            
            model.addConstr(
                quantity_vars[i] <= max_supplies[i] * order_vars[i],
                name=f"Max_Order_{vendor_names[i].replace(' ', '_')}"
            )
        return model, order_vars, quantity_vars
        
    except Exception as e:
        print(f"Error creating model: {e}")
        return None, None, None


def solve_model(model, order_vars, quantity_vars, data):
    """
    Solve the integer programming model and return solution
    
    Args:
        model: Gurobi model
        order_vars: Dictionary of order decision variables
        quantity_vars: Dictionary of order quantity variables
        data: Original data dictionary
        
    Returns:
        dict: Solution dictionary with order decisions and quantities
    """
    try:
        # Optimize the model
        model.optimize()
        
        # Check solution status
        if model.status == GRB.OPTIMAL:
            total_cost_int = int(round(model.objVal))
            print(f"Optimal solution found! Objective value: ${total_cost_int:,}")
            
            # Extract solution values
            order_decisions = []
            order_quantities = []
            
            for i in range(data["num_vendors"]):
                order_decisions.append(int(round(order_vars[i].X)))
                order_quantities.append(int(round(quantity_vars[i].X)))
            
            # Prepare solution dictionary
            solution = {
                "order_decisions": order_decisions,
                "order_quantities": order_quantities,
                "total_cost": total_cost_int,
                "unit_prices": data["unit_prices"],
                "delivery_charges": data["delivery_charges"],
                "vendor_names": data["vendor_names"],
                "status": "OPTIMAL"
            }
            
            # Print solution summary
            print("\nSolution Summary:")
            
            for i in range(data["num_vendors"]):
                vendor_name = data["vendor_names"][i]
                order_qty = order_quantities[i]
                order_decision = order_decisions[i]
                unit_cost = data["unit_prices"][i] * order_qty if order_qty > 0 else 0
                delivery_cost = data["delivery_charges"][i] * order_decision
                vendor_total = unit_cost + delivery_cost
                
                if order_qty > 0:
                    print(f"{vendor_name}:")
                    print(f"  Order Quantity: {order_qty} computers")
                    print(f"  Unit Cost: ${unit_cost:,}")
                    print(f"  Delivery Charge: ${delivery_cost:,}")
                    print(f"  Vendor Total: ${vendor_total:,}")
                else:
                    print(f"{vendor_name}: Not selected")
            
            total_order = sum(order_quantities)
            print(f"\nTotal Order Quantity: {total_order} computers")
            print(f"Total Cost: ${total_cost_int:,}")
            
            return solution
            
        elif model.status == GRB.INFEASIBLE:
            print("Model is infeasible!")
            model.computeIIS()
            model.write(f"{constant.LP_PATH}.ilp")
            print(f"IIS written to {constant.LP_PATH}.ilp")
            return {"status": "INFEASIBLE"}
            
        elif model.status == GRB.UNBOUNDED:
            print("Model is unbounded!")
            return {"status": "UNBOUNDED"}
            
        else:
            print(f"No optimal solution found. Status code: {model.status}")
            return {"status": "UNKNOWN"}
            
    except Exception as e:
        print(f"Error solving model: {e}")
        return {"status": "ERROR", "message": str(e)}


def export_model_files(model):
    """
    Export model to LP and MPS files
    
    Args:
        model: Gurobi model
    """
    try:
        # Export to LP file
        model.write(constant.LP_PATH)
        print(f"Model exported to LP file: {constant.LP_PATH}")
        
        # Export to MPS file
        model.write(constant.MPS_PATH)
        print(f"Model exported to MPS file: {constant.MPS_PATH}")
        
        return True
    except Exception as e:
        print(f"Error exporting model files: {e}")
        return False