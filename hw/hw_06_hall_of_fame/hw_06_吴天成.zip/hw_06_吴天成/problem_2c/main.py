# -*- coding: utf-8 -*-
"""
main
"""

from io_openpyxl import read_data_openpyxl, write_solution_openpyxl
from io_pandas import read_data_pandas, write_solution_pandas
from model import create_model, solve_model, export_model_files
import constant
import os

def create_and_solve_model(data):
    """
    Create and solve the optimization model
    """
    # Create model
    model, order_vars, quantity_vars = create_model(data)
    if model is None or order_vars is None or quantity_vars is None:
        print("Model creation failed!")
        return None
    
    # Export model files option
    """
    export_choice = input("Export model files (LP/MPS)? (y/n): ").strip().lower()
    if export_choice == 'y':
        
        export_model_files(model)
    """
    #export_model_files(model)
    
    # Solve model
    solution = solve_model(model, order_vars, quantity_vars, data)
    
    if solution and solution.get('status') == 'OPTIMAL':
        print("Model solved successfully!")
    else:
        print("Model solution failed or no optimal solution found")
    
    return solution

def main():
    """
    Main program: solve computer ordering optimization problem
    """
    print("State University Computer Procurement Optimization")
    
    # Check if data file exists
    if not os.path.exists(constant.DATA_PATH):
        print(f"Error: Data file '{constant.DATA_PATH}' not found!")
        return
    
    print(f"Data file: {constant.DATA_PATH}")
    print()
    
    # Select IO method
    print("Select data Input/Output method:")
    print("1. Use openpyxl")
    print("2. Use pandas")
    
    choice = input("Enter choice (1 or 2): ").strip()
    
    if choice == "1":
        read_data_func = read_data_openpyxl
        write_solution_func = write_solution_openpyxl
        method_name = "openpyxl"
    elif choice == "2":
        read_data_func = read_data_pandas
        write_solution_func = write_solution_pandas
        method_name = "pandas"
    else:
        print("Invalid choice, using openpyxl")
        read_data_func = read_data_openpyxl
        write_solution_func = write_solution_openpyxl
        method_name = "openpyxl"
    
    print(f"\nUsing {method_name} for data I/O...")
    
    try:
        # Read data from Excel
        print("Reading data from Excel...")
        model_data = read_data_func()
        if model_data is None:
            print("Data reading failed!")
            return
        
        print(f"Data loaded: {model_data['num_vendors']} vendors")
        print(f"Total demand: {model_data['total_demand']} computers")
        print()
        
        # Create and solve model
        solution = create_and_solve_model(model_data)
        if solution is None or solution.get('status') != 'OPTIMAL':
            print("No optimal solution obtained")
            return
        
        # Write solution back to Excel
        print("\nWriting solution to Excel...")
        success = write_solution_func(solution)
        
        if success:
            print("Task completed!")
            print(f"Solution written to '{constant.OUTPUT_SHEET_NAME}' sheet")
            print(f"Total cost: ${solution['total_cost']:,}")
        else:
            print("Error: Solution write failed")
        
    except KeyboardInterrupt:
        print("\nProgram interrupted by user")
    except Exception as e:
        print(f"\nError: {e}")

if __name__ == "__main__":
    main()