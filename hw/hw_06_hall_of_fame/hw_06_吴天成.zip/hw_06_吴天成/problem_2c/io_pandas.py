# -*- coding: utf-8 -*-
"""
io_pandas.py
"""
import pandas as pd
import openpyxl
import constant

def read_data_pandas():
    """
    Read data from Excel file using pandas for Computer Procurement Problem
    """
    try:
        # Read the entire sheet into DataFrame (0-indexed)
        df = pd.read_excel(
            constant.DATA_PATH, 
            sheet_name=constant.INPUT_SHEET_NAME, 
            header=None
        )
        
        # Read unit prices
        unit_prices = []
        for col in range(constant.UNIT_PRICE_COL_START - 1, constant.UNIT_PRICE_COL_END):
            value = df.iloc[constant.UNIT_PRICE_ROW - 1, col]
            unit_prices.append(float(value) if pd.notnull(value) else 0.0)
        
        # Read delivery charges
        delivery_charges = []
        for col in range(constant.DELIVERY_CHARGE_COL_START - 1, constant.DELIVERY_CHARGE_COL_END):
            value = df.iloc[constant.DELIVERY_CHARGE_ROW - 1, col]
            delivery_charges.append(float(value) if pd.notnull(value) else 0.0)
        
        # Read maximum supplies
        max_supplies = []
        for col in range(constant.MAX_SUPPLY_COL_START - 1, constant.MAX_SUPPLY_COL_END):
            value = df.iloc[constant.MAX_SUPPLY_ROW - 1, col]
            max_supplies.append(int(value) if pd.notnull(value) else 0)
        
        # Read other constraints parameters
        min_order_value = df.iloc[constant.MIN_ORDER_ROW - 1, constant.MIN_ORDER_COL - 1]
        min_order = int(min_order_value) if pd.notnull(min_order_value) else 200
        
        total_demand_value = df.iloc[constant.TOTAL_DEMAND_ROW - 1, constant.TOTAL_DEMAND_COL - 1]
        total_demand = int(total_demand_value) if pd.notnull(total_demand_value) else 1100
        
        # Read current order decisions
        order_decisions = []
        for col in range(constant.ORDER_DECISION_COL_START - 1, constant.ORDER_DECISION_COL_END):
            value = df.iloc[constant.ORDER_DECISION_ROW - 1, col]
            order_decisions.append(int(value) if pd.notnull(value) else 0)
        
        # Read current order quantities
        order_quantities = []
        for col in range(constant.ORDER_QUANTITY_COL_START - 1, constant.ORDER_QUANTITY_COL_END):
            value = df.iloc[constant.ORDER_QUANTITY_ROW - 1, col]
            order_quantities.append(int(value) if pd.notnull(value) else 0)
        
        # Prepare data dictionary
        data = {
            "vendor_names": constant.VENDOR_NAMES,
            "unit_prices": unit_prices,
            "delivery_charges": delivery_charges,
            "max_supplies": max_supplies,
            "min_order": min_order,
            "total_demand": total_demand,
            "num_vendors": constant.NUM_VENDORS,
            "order_decisions": order_decisions,
            "order_quantities": order_quantities
        }
        
        print(f"Pandas data reading successful! Read {len(unit_prices)} vendors data.")
        print(f"Data summary: min_order={min_order}, total_demand={total_demand}")
        return data
        
    except Exception as e:
        print(f"Pandas data reading error: {e}")
        return None

def write_solution_pandas(solution_dict):
    """
    Write solution results to Excel using pandas and openpyxl
    Maintain the original worksheet format and add solution to new sheet
    """
    try:
        # Load workbook with openpyxl for formatting
        workbook = openpyxl.load_workbook(constant.DATA_PATH)
        
        # Remove output sheet if it already exists
        if constant.OUTPUT_SHEET_NAME in workbook.sheetnames:
            del workbook[constant.OUTPUT_SHEET_NAME]
        
        # Create new worksheet with exact same format as input sheet
        input_sheet = workbook[constant.INPUT_SHEET_NAME]
        output_sheet = workbook.create_sheet(constant.OUTPUT_SHEET_NAME)
        
        # Copy all content and formatting from input sheet
        for row in input_sheet.iter_rows():
            for cell in row:
                new_cell = output_sheet.cell(
                    row=cell.row, 
                    column=cell.column, 
                    value=cell.value
                )
                # Copy cell style
                if cell.has_style:
                    new_cell.font = cell.font.copy()
                    new_cell.border = cell.border.copy()
                    new_cell.fill = cell.fill.copy()
                    new_cell.number_format = cell.number_format
                    new_cell.protection = cell.protection.copy()
                    new_cell.alignment = cell.alignment.copy()
        
        # Update order decisions
        for i, col in enumerate(range(constant.ORDER_DECISION_COL_START, 
                                     constant.ORDER_DECISION_COL_END + 1), 0):
            value = solution_dict['order_decisions'][i]
            output_sheet.cell(row=constant.ORDER_DECISION_ROW, column=col, value=value)
        
        # Update order quantities
        for i, col in enumerate(range(constant.ORDER_QUANTITY_COL_START,
                                     constant.ORDER_QUANTITY_COL_END + 1), 0):
            value = solution_dict['order_quantities'][i]
            output_sheet.cell(row=constant.ORDER_QUANTITY_ROW, column=col, value=value)
        
        # Update total order quantity
        total_order = sum(solution_dict['order_quantities'])
        output_sheet.cell(row=constant.TOTAL_ORDER_FORMULA_ROW, 
                         column=constant.TOTAL_ORDER_FORMULA_COL, 
                         value=total_order)
        
        # Update unit cost subtotal
        unit_cost_subtotal = sum(solution_dict['order_quantities'][i] * solution_dict['unit_prices'][i] 
                                for i in range(constant.NUM_VENDORS))
        output_sheet.cell(row=constant.UNIT_COST_FORMULA_ROW,
                         column=constant.UNIT_COST_FORMULA_COL,
                         value=unit_cost_subtotal)
        
        # Update delivery cost subtotal
        delivery_cost_subtotal = sum(solution_dict['order_decisions'][i] * solution_dict['delivery_charges'][i]
                                    for i in range(constant.NUM_VENDORS))
        output_sheet.cell(row=constant.DELIVERY_COST_FORMULA_ROW,
                         column=constant.DELIVERY_COST_FORMULA_COL,
                         value=delivery_cost_subtotal)
        
        # Update total cost
        total_cost = unit_cost_subtotal + delivery_cost_subtotal
        cell_totalCost = output_sheet.cell(row=constant.TOTAL_COST_ROW,
                                             column=constant.TOTAL_COST_COL,
                                             value=total_cost)
        cell_totalCost.number_format = '$#,##0'
        
        workbook.save(constant.DATA_PATH)
        workbook.close()
        return True
        
    except Exception as e:
        print(f"Pandas solution writing error: {e}")
        return False