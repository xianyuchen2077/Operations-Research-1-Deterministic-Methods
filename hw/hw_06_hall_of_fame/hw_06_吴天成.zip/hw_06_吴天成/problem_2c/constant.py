# -*- coding: utf-8 -*-
"""
Constant
"""

# Data file path and worksheet name
DATA_PATH = "./data/problem_2b.xlsx"
INPUT_SHEET_NAME = "Sheet1"

# Output worksheet name
OUTPUT_SHEET_NAME = "Solution_Gurobi"

LP_PATH = "./instance/ComputerOrderingProblem.lp"
MPS_PATH = "./instance/ComputerOrderingProblem.mps"


# Number of vendors
NUM_VENDORS = 3
# Vendor names list
VENDOR_NAMES = ["Vendor 1", "Vendor 2", "Vendor 3"]
# Variable name prefixes
VAR_ORDER_PREFIX = "order_"  # Order decision variable prefix
VAR_QUANTITY_PREFIX = "quantity_"  # Order quantity variable prefix

# Model name
MODEL_NAME = "Computer_Ordering_Optimization"



# Unit price data
UNIT_PRICE_ROW = 4
UNIT_PRICE_COL_START = 2       # B4: Vendor 1 unit price
UNIT_PRICE_COL_END = 4         # D4: Vendor 3 unit price

# Delivery charge data
DELIVERY_CHARGE_ROW = 5
DELIVERY_CHARGE_COL_START = 2  # B5: Vendor 1 delivery charge
DELIVERY_CHARGE_COL_END = 4    # D5: Vendor 3 delivery charge

# Order decision
ORDER_DECISION_ROW = 8
ORDER_DECISION_COL_START = 2   # B8: Vendor 1 order decision
ORDER_DECISION_COL_END = 4     # D8: Vendor 3 order decision
# Order quantity 
ORDER_QUANTITY_ROW = 9
ORDER_QUANTITY_COL_START = 2   # B9: Vendor 1 order quantity
ORDER_QUANTITY_COL_END = 4     # D9: Vendor 3 order quantity
# Maximum supply
MAX_SUPPLY_ROW = 12
MAX_SUPPLY_COL_START = 2       # B12: Vendor 1 maximum supply
MAX_SUPPLY_COL_END = 4         # D12: Vendor 3 maximum supply

# Minimum order quantity
MIN_ORDER_ROW = 14
MIN_ORDER_COL = 2              # B14: Minimum order quantity (200)
# Total demand 
TOTAL_DEMAND_ROW = 15
TOTAL_DEMAND_COL = 2           # B15: Total demand (1100)

# Total order quantity
TOTAL_ORDER_FORMULA_ROW = 15
TOTAL_ORDER_FORMULA_COL = 4    # D15: The sum of vendor 1~3 order quantities
                               # =SUM(B9+C9+D9)
# Sum of unit costs
UNIT_COST_FORMULA_ROW = 18
UNIT_COST_FORMULA_COL = 4      # D18: The sum of vendor 1~3 unit costs
                               # =SUM(B4*B9+C4*C9+D4*D9)
#Sum of delivery costs
DELIVERY_COST_FORMULA_ROW = 19
DELIVERY_COST_FORMULA_COL = 4  # D19: The sum of vendor 1~3 delivery costs
                               # =SUM(B5*B8+C5*C8+D5*D8)
# Total cost
TOTAL_COST_ROW = 18
TOTAL_COST_COL = 2             # B18: The sum of unit costs and delivery costs
                               # =SUM(D18+D19)

