$x_{1,2,3}$ denote for the number of computers purchased from Vendor $i=1,2,3$, which are integer variables.

$y_{1,2,3}$ denote for whether to buy from Vendor $i=1,2,3$, which are binary variables.

$s_{1,2,3}$ denote for the at most number of computers of Vendor $i=1,2,3$.

$c_{1,2,3}$ denote for the cost per computer from Vendor $i=1,2,3$.

$d_{1,2,3}$ denote for the delivery cost of Vendor $i=1,2,3$.

$m$ denotes for the minimum order, which is $200$. 

$r$ denotes for the number of computers required, which is $1100$.

$Z$ denotes for total profit.
$$
\begin{aligned}
&\min&Z=c^T&x+d^Ty&&&\text{Total Cost}\\
&s.t.&&x_i\ge my_i&\forall i=1,2,3&&\text{Minimum Order}\\
&&&x_i\le s_iy_i&\forall i=1,2,3&&\text{Maximum Order}\\
&&&\sum x_i=r&&&\text{Purchase Amount}\\
&&&x_i\ge0&\forall i=1,2,3&&\text{Non-negative}\\
&&&x_i\text{ integers}&\forall i=1,2,3&&\text{Integer Constraint}\\
&&&y_i\text{ binaries}&\forall i=1,2,3&&\text{Binary Variables}
\end{aligned}
$$

$$
\begin{aligned}
&\min&Z=&500x_1+350x_2+250x_3+5000y_1+4000y_2+6000y_3\\
&s.t.&&x_1\ge200y_1\\
&&&x_2\ge 200y_2\\
&&&x_3\ge200y_3\\
&&&x_1\le500y_1\\
&&&x_2\le900y_2\\
&&&x_3\le400y_3\\
&&&x_1+x_2+x_3=1100\\
&&&x_{1,2,3}\ge 0\\
&&&x_{1,2,3}\text{ integers}\\
&&&y_{1,2,3}\text{ binaries}
\end{aligned}
$$

