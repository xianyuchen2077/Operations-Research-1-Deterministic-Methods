"""
Formulate and solve the Wyndor Example using Gurobi.
"""

import gurobipy as grb

import constant


def formulateModel(purchaseCosts, deliveryCosts, maximumOrders, minimumOrders, requiredPurchase) -> grb.Model:
    """
    Formulate a Gurobi model based on the given instance data.

    Parameters
    ----------
    purchaseCosts : dict
        The cost per computer for each vendor
        - Keys: vendor names (`Vendor 1`, `Vendor 2`, `Vendor 3`)
        - Values: cost per computer
    deliveryCosts : dict
        The delivery cost for each vendor
        - Keys: vendor names (`Vendor 1`, `Vendor 2`, `Vendor 3`)
        - Values: delivery cost
    maximumOrders : dict
        The maximum orders allowed for each vendor
        - Keys: vendor names (`Vendor 1`, `Vendor 2`, `Vendor 3`)
        - Values: maximum orders
    minimumOrders : int
        The minimum orders required 
    requiredPurchase : int
        The total number of computers required

    Returns
    -------
    model : gurobipy.Model
        The formulated Gurobi model
    """

    # Create a Gurobi model.
    model = grb.Model(constant.MODEL_NAME)

    # Define decision variables.
    purchaseDecisions = {}
    for vendor, amount in purchaseCosts.items():
        purchaseDecisions[vendor] = model.addVar(lb=0.0,
                                                         ub=grb.GRB.INFINITY,
                                                         vtype=grb.GRB.INTEGER,
                                                         name=f"{vendor}_amount")
        
    whetherDecisions = {}
    
    for vendor in purchaseCosts.keys():
        whetherDecisions[vendor] = model.addVar(lb=0.0,
                                                ub=1.0,
                                                vtype=grb.GRB.BINARY,
                                                name=f"{vendor}_whether")

    # Define the objective function.
    objExpr = grb.LinExpr()
    for vendor, cost in purchaseCosts.items():
        objExpr += cost * purchaseDecisions[vendor]
    
    for vendor, cost in deliveryCosts.items():
        objExpr += cost * whetherDecisions[vendor]
    
     # Define the constraints.
    model.setObjective(objExpr, grb.GRB.MINIMIZE)

    # Define the constraints.
    for vendor, maximumOrder in maximumOrders.items():
        # For each plant, the total used hours <= the available hours.
        print(purchaseDecisions.keys())
        
        lhsExpr = grb.LinExpr()
        maximumAmount = grb.LinExpr()
        minimumAmount = grb.LinExpr()
        lhsExpr += purchaseDecisions[vendor]
        maximumAmount += maximumOrder*whetherDecisions[vendor]
        minimumAmount += minimumOrders*whetherDecisions[vendor]
        
        model.addConstr(lhsExpr <= maximumAmount, f"{vendor}_maximum")
        model.addConstr(lhsExpr >= minimumAmount, f"{vendor}_minimum")
        

    # Total requirement constraint
    totalPurchaseExpr = grb.LinExpr()
    for vendor in purchaseCosts.keys():
        totalPurchaseExpr += purchaseDecisions[vendor]
        
    model.addConstr(totalPurchaseExpr == requiredPurchase, "total_requirement")
    # Return the model.
    return model


def solveModel(model) -> None:
    """
    Optimize the given Gurobi model.

    Parameters
    ----------
    model : gurobipy.Model
        The Gurobi model to be optimized

    """
    model.optimize()


def getOptimalSolution(model) -> dict[str, float]:
    """
    Get the optimal solution of the (optimized) Gurobi model.

    Parameters
    ----------
    model : gurobipy.Model
        The Gurobi model to be optimized

    Returns
    -------
    soln : dict
        The optimal solutions
        - Keys: variable names
        - Values: optimal decision variable values
    objVal : float
        The optimal objective function value
    """
    soln = {}
    for var in model.getVars():
        soln[var.VarName] = var.X

    objVal = model.objVal

    # Print the optimal solutions and objective function value.
    print("\nThe optimal solutions:")
    for varName, varValue in soln.items():
        print(f"    {varName}: {varValue}")

    print(f"The optimal objective function value: {objVal}\n")

    return soln, objVal


def getOptimalDualSolution(model, constrNames=None) -> dict[str, float]:
    """
    Get the optimal dual variable values of a given set of constraints.

    Parameters
    ----------
    model : gurobipy.Model
        The Gurobi model to extract the optimal dual variable values from
    constrNames : str or list of str, optional
        The names of the constraints to extract the optimal dual variable values from
        - If None, extract for all constraints
        - If a string, extract for the specified constraint
        - If a list of strings, extract for the specified set of constraints

    Returns
    -------
    duals : dict
        The optimal dual variable values of the specified constraints
        - Keys: constraint names
        - Values: optimal dual variable values
    """

    duals = {}

    if constrNames is None:
        constrs = model.getConstrs()

        for constr in constrs:
            duals[constr.constrName] = constr.pi
            print(f"{constr.constrName}: Optimal dual variable value = {constr.pi}")

        return duals

    if isinstance(constrNames, str):
        constrNames = [constrNames]

    if not isinstance(constrNames, list):
        raise ValueError("constrNames must be a string or a list of strings")

    for constrName in constrNames:
        constr = model.getConstrByName(constrName)
        if constr is not None:
            duals[constrName] = constr.pi
            print(f"Constr {constrName}: Optimal dual variable value = {constr.pi}")
        else:
            duals[constrName] = None
            print(f"{constrName}: Not found")

    return duals


def readModel(filePath) -> grb.Model:
    """
    Load a Gurobi model from a MPS or LP file.

    Parameters
    ----------
    filePath : str
        The path to the file to load the model from

    Returns
    -------
    model : gurobipy.Model
        The loaded Gurobi model
    """
    model = grb.read(filePath)

    return model


def saveModel(model, filePath) -> None:
    """
    Save the given Gurobi model to a file, either in MPS or LP format.

    Parameters
    ----------
    model : gurobipy.Model
        The Gurobi model to be saved
    filePath : str
        The path to the file to save the model to
    """
    model.write(filePath)
