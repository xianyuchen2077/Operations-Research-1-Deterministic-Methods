"""
Reading from and writing to an Excel file using openpyxl.
"""

from openpyxl import load_workbook

import constant


def readDataOpenpyxl() -> tuple[dict, dict, dict,]:
    """
    Given an Excel file, read production planning data from Excel file using openpyxl.

    Returns
    -------
    
    purchaseCosts : dict
        The cost per computer for each vendor
        - Keys: vendor names (`Vendor 1`, `Vendor 2`, `Vendor 3`)
        - Values: cost per computer
    deliveryCosts : dict
        The delivery cost for each vendor
        - Keys: vendor names (`Vendor 1`, `Vendor 2`, `Vendor 3`)
        - Values: delivery cost
    maximumOrders : dict
        The maximum orders allowed for each vendor
        - Keys: vendor names (`Vendor 1`, `Vendor 2`, `Vendor 3`)
        - Values: maximum orders
    minimumOrders : int
        The minimum orders required
    requiredPurchase : int
        The total number of computers required
        
    """

    # Load a workbook from DATA_PATH
    inputBook = load_workbook(constant.DATA_PATH)

    # Find the sheet in which you want to write the solution
    inputSheet = inputBook[constant.SHEET_NAME]


    purchaseCosts = {}
    for vendorName in constant.VENDOR_NAMES:
        colIndex = constant.INPUT_COST_PER_COMPUTER_START_COL + constant.VENDOR_NAMES.index(vendorName)
        costValue = inputSheet.cell(constant.INPUT_COST_PER_COMPUTER_START_ROW, colIndex).value
        purchaseCosts[vendorName] = costValue

    deliveryCosts = {} 
    for vendorName in constant.VENDOR_NAMES:
        colIndex = constant.INPUT_DELIVERY_COST_START_COL + constant.VENDOR_NAMES.index(vendorName)
        deliveryCostValue = inputSheet.cell(constant.INPUT_DELIVERY_COST_START_ROW, colIndex).value
        deliveryCosts[vendorName] = deliveryCostValue

    maximumOrders = {}
    for vendorName in constant.VENDOR_NAMES:
        colIndex = constant.INPUT_MAXIMUM_ORDERS_START_COL + constant.VENDOR_NAMES.index(vendorName)
        maxOrderValue = inputSheet.cell(constant.INPUT_MAXIMUM_ORDERS_START_ROW, colIndex).value
        maximumOrders[vendorName] = maxOrderValue
        
    minimumOrders = inputSheet.cell(constant.INPUT_MINIMUM_ORDERS_START_ROW, 
                                   constant.INPUT_MINIMUM_ORDERS_START_COL).value
    
    requiredPurchase = inputSheet.cell(constant.INPUT_TOTAL_REQUIREMENT_START_ROW,
                                      constant.INPUT_TOTAL_REQUIREMENT_START_COL).value

    return purchaseCosts, deliveryCosts, maximumOrders, minimumOrders, requiredPurchase


def writeDataOpenpyxl(soln, objVal) -> None:
    """
    Write the solution back to the Excel file using openpyxl.

    Parameters
    ----------
    soln : dict
        The optimal solutions
        - Keys: variable names
        - Values: optimal decision variable values
    objVal : float
        The optimal objective function value
    """
    # Load a workbook from DATA_PATH
    outputBook = load_workbook(constant.DATA_PATH)

    # Find the sheet to write the solution
    if outputBook.sheetnames.__contains__(constant.OUTPUT_SHEET_NAME):
        outputSheet = outputBook[constant.OUTPUT_SHEET_NAME]
    else:
        outputSheet = outputBook.create_sheet(title=constant.OUTPUT_SHEET_NAME)

    outputSheet.cell(constant.OUTPUT_TITLE_START_ROW, constant.OUTPUT_TITLE_START_COL, "Vendor 1")
    outputSheet.cell(constant.OUTPUT_TITLE_START_ROW, constant.OUTPUT_TITLE_START_COL + 1, "Vendor 2")
    outputSheet.cell(constant.OUTPUT_TITLE_START_ROW, constant.OUTPUT_TITLE_START_COL + 2, "Vendor 3")
    outputSheet.cell(constant.OUTPUT_LABEL_START_ROW, constant.OUTPUT_LABEL_START_COL, "Computer Purchased")
    outputSheet.cell(constant.OUTPUT_LABEL_START_ROW+1, constant.OUTPUT_LABEL_START_COL, "Whether Purchased (0/1)")
    outputSheet.cell(constant.OUTPUT_TOTAL_LABEL_START_ROW, constant.OUTPUT_TOTAL_LABEL_START_COL, "Total Cost")

    # Write the optimal solutions to the outputSheet
    for j, vendor in enumerate(constant.VENDOR_NAMES):
        rowIndex = constant.OUTPUT_LABEL_START_ROW 
        colIndex = constant.OUTPUT_LABEL_START_COL + j + 1
        outputSheet.cell(rowIndex, colIndex, soln[vendor+"_amount"])
        
        outputSheet.cell(rowIndex + 1, colIndex, soln[vendor+"_whether"])

    outputSheet.cell(constant.OUTPUT_TOTAL_LABEL_START_ROW, constant.OUTPUT_TOTAL_LABEL_START_COL + 1, objVal)

    # Save the workbook
    outputBook.save(constant.DATA_PATH)
