The data workbook read is '../problem_2b.xlsx'.
You should have pandas, openpyxl, gurobipy installed on your Python environment.