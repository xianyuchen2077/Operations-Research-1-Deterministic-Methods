# README – Problem 2 (State University)

## File Structure

```
problem_2
│
├── problem_2a.pdf      # Integer Programming Model
├── problem_2b.xlsx     # Excel Solver and Gurobi Solutions
├── problem_2c/         # Python Implementation
│ ├── main.py           # Main execution script
│ ├── constant.py       # Constants and parameters
│ ├── model.py          # IP model formulation
│ └── io_openpyxl.py    # Excel I/O operations
└── README.md           # This document
```

## File Descriptions

- **problem_2a.pdf**: The complete integer programming formulation
- **problem_2b.xlsx**: Excel workbook with two worksheets:
  - **Solution_Excel**: Results from Excel Solver
  - **Solution_Gurobi**: Results from Gurobi
- **problem_2c/**: Directory containing Python implementation:
  - **main.py**: Main script that orchestrates the solution process
  - **constant.py**: Defines constants and parameters
  - **model.py**: Implements the integer programming model using Gurobi
  - **io_openpyxl.py**: Handles reading input data and writing results to Excel

## Requirements

- **Python Version**: 3.12
- **Required Packages**:
  - Openpyxl
  - Gurobi

## How to Run

1. Ensure Python 3.12, Openpyxl, and Gurobi are installed

2. Navigate to the `problem_2c` directory in command line

3. Execute the following command:
   
   ```
   python main.py
   ```

4. The program will automatically:
   
   - Read input data from `problem_2b.xlsx`
   - Solve the optimization problem using Gurobi
   - Write the solution results to the **Solution_Gurobi** worksheet in the Excel file
