"""
Reading from and writing to an Excel file using openpyxl.
"""

from openpyxl import load_workbook

import constant


def readDataOpenpyxl() -> tuple[dict, dict, dict, dict, dict]:
    """Read data from an Excel file using openpyxl.
    
    Returns
    -------
    charge pre computer : dict
        Unit cost of computers from each vendor

    total delivery charge : dict
        Total delivery cost from each vendor

    maximun order : dict
        Maximum number of computers available from each vendor

    minimun order : dict
        Minimum order per vendor

    total requirement : dict
        Total number of computers to be purchased
    """

    # Load a workbook from DATA_PATH
    inputBook = load_workbook(constant.DATA_PATH)

    # Find the sheet in which you want to read data
    inputSheet = inputBook[constant.SHEET_NAME]

    # Read data from the inputSheet and create dictionaries
    chargePreComputer = {}
    for i, vendorName in enumerate(constant.VENDOR_NAMES):
        colIndex = constant.INPUT_CHARGE_PER_COMPUTER_START_COL + i
        value = inputSheet.cell(constant.INPUT_CHARGE_PER_COMPUTER_START_ROW, colIndex).value
        chargePreComputer[vendorName] = value

    totalDeliveryCharge = {}
    for i, vendorName in enumerate(constant.VENDOR_NAMES):
        colIndex = constant.INPUT_TOTAL_DELIVERY_CHARGE_START_COL + i
        value = inputSheet.cell(constant.INPUT_TOTAL_DELIVERY_CHARGE_START_ROW, colIndex).value
        totalDeliveryCharge[vendorName] = value

    maximunOrder = {}
    for i, vendorName in enumerate(constant.VENDOR_NAMES):
        colIndex = constant.INPUT_MAXIMUN_ORDER_START_COL + i
        value = inputSheet.cell(constant.INPUT_MAXIMUN_ORDER_START_ROW, colIndex).value
        maximunOrder[vendorName] = value
        
    minimunOrder = {}
    for i, vendorName in enumerate(constant.VENDOR_NAMES):
        colIndex = constant.INPUT_MINIMUN_ORDER_START_COL + i
        value = inputSheet.cell(constant.INPUT_MINIMUN_ORDER_START_ROW, colIndex).value
        minimunOrder[vendorName] = value
    
    totalRequirement = {}
    totalRequirement[constant.TOTAL_REQUIREMENT_NAME] = inputSheet.cell(constant.INPUT_TOTAL_REQUIREMENT_START_ROW, constant.INPUT_TOTAL_REQUIREMENT_START_COL).value
    
    return chargePreComputer, totalDeliveryCharge, maximunOrder, minimunOrder, totalRequirement


def writeDataOpenpyxl(soln, objVal) -> None:
    """
    Write the solution back to the Excel file using openpyxl.
    """

    # Load a workbook from DATA_PATH
    outputBook = load_workbook(constant.DATA_PATH)

    # Find the sheet to write the solution
    outputSheet = outputBook[constant.SHEET_NAME]

    # Write data to the outputSheet
    for i, vendorName in enumerate(constant.VENDOR_NAMES):
        colIndex = constant.OUTPUT_PURCHASE_ANY_START_COL + i
        outputSheet.cell(constant.OUTPUT_PURCHASE_ANY_START_ROW, colIndex).value = soln[f"Purchase any of {vendorName}"]

    for i, vendorName in enumerate(constant.VENDOR_NAMES):
        colIndex = constant.OUTPUT_NUMBER_PURCHASED_START_COL + i
        outputSheet.cell(constant.OUTPUT_NUMBER_PURCHASED_START_ROW, colIndex).value = soln[f"Number purchased of {vendorName}"]

    outputSheet.cell(constant.OUTPUT_TOTAL_COST_START_ROW, constant.OUTPUT_TOTAL_COST_START_COL).value = objVal

    # Save the workbook to DATA_PATH
    outputBook.save(constant.DATA_PATH)
