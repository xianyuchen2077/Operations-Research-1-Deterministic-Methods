"""
Constants
"""

# Data file path and worksheet name
DATA_PATH = "../problem_2b.xlsx"
SHEET_NAME = "Solution_Gurobi"

# Charge pre computer data location
INPUT_CHARGE_PER_COMPUTER_START_ROW = 3
INPUT_CHARGE_PER_COMPUTER_START_COL = 2

# Total delivery charge data location
INPUT_TOTAL_DELIVERY_CHARGE_START_ROW = 4
INPUT_TOTAL_DELIVERY_CHARGE_START_COL = 2

# Maximun order data location
INPUT_MAXIMUN_ORDER_START_ROW = 6
INPUT_MAXIMUN_ORDER_START_COL = 2

# Minimun order data location
INPUT_MINIMUN_ORDER_START_ROW = 7
INPUT_MINIMUN_ORDER_START_COL = 2

# Total requirement data location
INPUT_TOTAL_REQUIREMENT_START_ROW = 15
INPUT_TOTAL_REQUIREMENT_START_COL = 2

# Output result location
OUTPUT_PURCHASE_ANY_START_ROW = 11
OUTPUT_PURCHASE_ANY_START_COL = 2

OUTPUT_NUMBER_PURCHASED_START_ROW = 13
OUTPUT_NUMBER_PURCHASED_START_COL = 2

OUTPUT_TOTAL_COST_START_ROW = 18
OUTPUT_TOTAL_COST_START_COL = 2

# Vendor names list
VENDOR_NAMES = ["Vendor_1", "Vendor_2", "Vendor_3"]

# Total requirement name
TOTAL_REQUIREMENT_NAME = "Total requirement"

# Model name
MODEL_NAME = "State University"
