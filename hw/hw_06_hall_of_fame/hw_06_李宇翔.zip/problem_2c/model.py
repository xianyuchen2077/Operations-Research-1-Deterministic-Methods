"""
Formulate and solve the Tatham Example using Gurobi.
"""

import gurobipy as grb

import constant


def formulateModel(chargePreComputer, totalDeliveryCharge, maximunOrder, minimunOrder, totalRequirement) -> grb.Model:
    """
    Formulate a Gurobi model based on the given instance data.

    Parameters
    ----------
    charge pre computer : dict
        Unit cost of computers from each vendor

    total delivery charge : dict
        Total delivery cost from each vendor

    maximun order : dict
        Maximum number of computers available from each vendor

    minimun order : dict
        Minimum order per vendor

    total requirement : dict
        Total number of computers to be purchased

    Returns
    -------
    model : grb.Model
        The formulated Gurobi model.
    """

    # Create a new model
    model = grb.Model(constant.MODEL_NAME)

    # Define decision variables
    purchaseAny = {}
    for vendorName in constant.VENDOR_NAMES:
        purchaseAny[vendorName] = model.addVar(vtype=grb.GRB.BINARY, name=f"Purchase any of {vendorName}")

    numberPurchased = {}
    for vendorName in constant.VENDOR_NAMES:
        numberPurchased[vendorName] = model.addVar(vtype=grb.GRB.INTEGER, name=f"Number purchased of {vendorName}")

    # Define the objective function
    objExpr = grb.LinExpr()
    for vendorName in constant.VENDOR_NAMES:
        objExpr += purchaseAny[vendorName] * totalDeliveryCharge[vendorName] + numberPurchased[vendorName] * chargePreComputer[vendorName]
    model.setObjective(objExpr, grb.GRB.MINIMIZE)

    # Define the maximun/minimun constraint
    for vendorName in constant.VENDOR_NAMES:
        lhsExpr = grb.LinExpr()
        lhsExpr += numberPurchased[vendorName] - purchaseAny[vendorName] * maximunOrder[vendorName]
        model.addConstr(lhsExpr <= 0, name=f"Maximun number of {constant.VENDOR_NAMES}")

    for vendorName in constant.VENDOR_NAMES:
        lhsExpr = grb.LinExpr()
        lhsExpr += numberPurchased[vendorName] - purchaseAny[vendorName] * minimunOrder[vendorName]
        model.addConstr(lhsExpr >= 0, name=f"Minimun number of {constant.VENDOR_NAMES}")

    lhsExpr = grb.LinExpr()
    for vendorName in constant.VENDOR_NAMES:
        lhsExpr += numberPurchased[vendorName]
    model.addConstr(lhsExpr >= totalRequirement[constant.TOTAL_REQUIREMENT_NAME], name=constant.TOTAL_REQUIREMENT_NAME)

    # Return the model
    return model


def solveModel(model) -> None:
    """
    Optimize the given Gurobi model.

    Parameters
    ----------
    model : gurobipy.Model
        The Gurobi model to be optimized

    """
    model.optimize()


def getOptimalSolution(model) -> dict[str, float]:
    """
    Get the optimal solution and objective value of the optimized Gurobi model.

    Parameters
    ----------
    model : gurobipy.Model
        The Gurobi model to be optimized

    Returns
    -------
    soln : dict
        The optimal solutions
        - Keys: variable names
        - Values: optimal decision variable values
    objVal : float
        The optimal objective function value
    """
    soln = {}
    for var in model.getVars():
        soln[var.VarName] = var.X

    objVal = model.objVal

    # Print the optimal solutions and objective function value.
    print("\nThe optimal solutions:")
    for varName, varValue in soln.items():
        print(f"    {varName}: {varValue}")

    print(f"The optimal objective function value: {objVal}\n")

    return soln, objVal
