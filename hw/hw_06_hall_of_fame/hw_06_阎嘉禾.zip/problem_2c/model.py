"""
Formulate and solve the Wyndor Example using Gurobi.
"""

import gurobipy as grb

import constant


def formulateModel(prices, deliveryCharges, upperLimits, lowerLimit, M, demand) -> grb.Model:
    """
    Formulate a Gurobi model based on the given instance data.

    Parameters
    ----------
    prices : dict
        The price per computer at each vendor
        - Keys: vendor names (`vendor 1`, `vendor 2`, `vendor 3`)
        - Values: price per computer
    deliveryCharges : dict
        The delivery charge at each vendor
        - Keys: vendor names (`vendor 1`, `vendor 2`, `vendor 3`)
        - Values: delivery charge
    upperLimits : dict
        The upper purchase limit at each vendor
        - Keys: vendor names (`vendor 1`, `vendor 2`, `vendor 3`)
        - Values: upper purchase limit
    lowerLimit : int
        The lower purchase limit
    M : int
        The M value used in the model
    demand : int
        The demand of computers

    Returns
    -------
    model : gurobipy.Model
        The formulated Gurobi model
    """

    # Create a Gurobi model.
    model = grb.Model(constant.MODEL_NAME)

    # Define decision variables.
    whetherToPurchaseDecisions = {}
    for vendor, price in prices.items():
        whetherToPurchaseDecisions[vendor] = model.addVar(vtype=grb.GRB.BINARY,
                                                          name=f"{constant.WHETHER_TO_PURCHASE_PREFIX + vendor}")
    purchaseNumberDecisions = {}
    for vendor, price in prices.items():
        purchaseNumberDecisions[vendor] = model.addVar(lb=0.0,
                                                       ub=grb.GRB.INFINITY,
                                                       vtype=grb.GRB.INTEGER,
                                                       name=f"{constant.PURCHASE_NUMBER_PREFIX + vendor}")

    # Define the objective function.
    objExpr = grb.LinExpr()
    for vendor, price in prices.items():
        objExpr += price * purchaseNumberDecisions[vendor]
    for vendor, charge in deliveryCharges.items():
        objExpr += charge * whetherToPurchaseDecisions[vendor]
    model.setObjective(objExpr, grb.GRB.MINIMIZE)

    # Define the constraints.

    # Fulfill the demand.
    lhsExpr = grb.LinExpr()
    for vendor, price in prices.items():
        lhsExpr += purchaseNumberDecisions[vendor]
    model.addConstr(lhsExpr >= demand, f"{constant.DEMAND_NAME}")

    # At each vendor, purchased <= upper limit.
    for vendor, limit in upperLimits.items():
        lhsExpr = grb.LinExpr()
        lhsExpr += purchaseNumberDecisions[vendor]
        model.addConstr(lhsExpr <= limit, f"{constant.UPPER_PURCHASE_LIMIT_PREFIX + vendor}")

    # At each vendor, purchased >= lower limit.
    for vendor, price in prices.items():
        lhsExpr = grb.LinExpr()
        rhsExpr = grb.LinExpr()
        lhsExpr += purchaseNumberDecisions[vendor]
        rhsExpr += lowerLimit * whetherToPurchaseDecisions[vendor]
        model.addConstr(lhsExpr >= rhsExpr, f"{constant.LOWER_PURCHASE_LIMIT_PREFIX + vendor}")

    # At each vendor, purchased > 0 only when whether_to_purchase == 1.
    for vendor, price in prices.items():
        lhsExpr = grb.LinExpr()
        rhsExpr = grb.LinExpr()
        lhsExpr += purchaseNumberDecisions[vendor]
        rhsExpr += M * whetherToPurchaseDecisions[vendor]
        model.addConstr(lhsExpr <= rhsExpr, f"{constant.LOGIC_PREFIX + vendor}")

    # Return the model.
    return model


def solveModel(model) -> None:
    """
    Optimize the given Gurobi model.

    Parameters
    ----------
    model : gurobipy.Model
        The Gurobi model to be optimized

    """
    model.optimize()


def getOptimalSolution(model) -> dict[str, float]:
    """
    Get the optimal solution of the (optimized) Gurobi model.

    Parameters
    ----------
    model : gurobipy.Model
        The Gurobi model to be optimized

    Returns
    -------
    soln : dict
        The optimal solutions
        - Keys: variable names
        - Values: optimal decision variable values
    objVal : float
        The optimal objective function value
    """
    soln = {}
    for var in model.getVars():
        soln[var.VarName] = var.X

    objVal = model.objVal

    # Print the optimal solutions and objective function value.
    print("\nThe optimal solutions:")
    for varName, varValue in soln.items():
        print(f"    {varName}: {varValue}")

    print(f"The optimal objective function value: {objVal}\n")

    return soln, objVal


def getOptimalDualSolution(model, constrNames=None) -> dict[str, float]:
    """
    Get the optimal dual variable values of a given set of constraints.

    Parameters
    ----------
    model : gurobipy.Model
        The Gurobi model to extract the optimal dual variable values from
    constrNames : str or list of str, optional
        The names of the constraints to extract the optimal dual variable values from
        - If None, extract for all constraints
        - If a string, extract for the specified constraint
        - If a list of strings, extract for the specified set of constraints

    Returns
    -------
    duals : dict
        The optimal dual variable values of the specified constraints
        - Keys: constraint names
        - Values: optimal dual variable values
    """

    duals = {}

    if constrNames is None:
        constrs = model.getConstrs()

        for constr in constrs:
            duals[constr.constrName] = constr.pi
            print(f"{constr.constrName}: Optimal dual variable value = {constr.pi}")

        return duals

    if isinstance(constrNames, str):
        constrNames = [constrNames]

    if not isinstance(constrNames, list):
        raise ValueError("constrNames must be a string or a list of strings")

    for constrName in constrNames:
        constr = model.getConstrByName(constrName)
        if constr is not None:
            duals[constrName] = constr.pi
            print(f"Constr {constrName}: Optimal dual variable value = {constr.pi}")
        else:
            duals[constrName] = None
            print(f"{constrName}: Not found")

    return duals


def readModel(filePath) -> grb.Model:
    """
    Load a Gurobi model from a MPS or LP file.

    Parameters
    ----------
    filePath : str
        The path to the file to load the model from

    Returns
    -------
    model : gurobipy.Model
        The loaded Gurobi model
    """
    model = grb.read(filePath)

    return model


def saveModel(model, filePath) -> None:
    """
    Save the given Gurobi model to a file, either in MPS or LP format.

    Parameters
    ----------
    model : gurobipy.Model
        The Gurobi model to be saved
    filePath : str
        The path to the file to save the model to
    """
    model.write(filePath)
