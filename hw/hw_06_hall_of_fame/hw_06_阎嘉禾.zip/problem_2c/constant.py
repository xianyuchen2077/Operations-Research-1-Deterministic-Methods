"""
Constants
"""

# Data file path and worksheet name
DATA_PATH = "../problem_2b.xlsx"
INPUT_SHEET_NAME = "Data"
OUTPUT_SHEET_NAME = "Solution_Gurobi"

LP_PATH = "./instance/result.lp"
MPS_PATH = "./instance/result.mps"

# Price per computer location (vendor 1, 2, 3)
INPUT_PRICE_START_ROW = 2
INPUT_PRICE_START_COL = 2

# Delivery charge location (vendor 1, 2, 3)
INPUT_DELIVERY_CHARGE_START_ROW = 2
INPUT_DELIVERY_CHARGE_START_COL = 3

# Upper purchase limit location (vendor 1, 2, 3)
INPUT_UPPER_PURCHASE_LIMIT_START_ROW = 2
INPUT_UPPER_PURCHASE_LIMIT_START_COL = 4

# Lower purchase limit location
INPUT_LOWER_PURCHASE_LIMIT_ROW = 2
INPUT_LOWER_PURCHASE_LIMIT_COL = 6

# M location
INPUT_M_ROW = 2
INPUT_M_COL = 7

# Demand location
INPUT_DEMAND_ROW = 2
INPUT_DEMAND_COL = 8

# Output result location
OUTPUT_WHETHER_TO_PURCHASE_START_ROW = 1
OUTPUT_WHETHER_TO_PURCHASE_START_COL = 2

OUTPUT_PURCHASE_NUMBER_START_ROW = 4
OUTPUT_PURCHASE_NUMBER_START_COL = 2

OUTPUT_COST_ROW = 7
OUTPUT_COST_COL = 2

# Vendor names list
VENDOR_NAMES = ["vendor_1", "vendor_2", "vendor_3"]

# Variable name prefixes
WHETHER_TO_PURCHASE_PREFIX = "whether_to_purchase_at_"
PURCHASE_NUMBER_PREFIX = "purchase_number_at_"

# Constraint names and name prefixes
DEMAND_NAME = "demand"
UPPER_PURCHASE_LIMIT_PREFIX = "upper_purchase_limit_at_"
LOWER_PURCHASE_LIMIT_PREFIX = "lower_purchase_limit_at_"
LOGIC_PREFIX = "logic_at_"

# Output cost label name
OUTPUT_COST_LABEL = "cost"

# Output label width
OUTPUT_LABEL_WIDTH = 30

# Model name
MODEL_NAME = "State_University"
