"""
Reading from and writing to an Excel file using openpyxl.
"""

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

import constant


def readDataOpenpyxl() -> tuple[dict, dict, dict, int, int, int]:
    """
    Given an Excel file, read purchase planning data from Excel file using openpyxl.

    Returns
    -------
    prices : dict
        The price per computer at each vendor
        - Keys: vendor names (`vendor 1`, `vendor 2`, `vendor 3`)
        - Values: price per computer
    deliveryCharges : dict
        The delivery charge at each vendor
        - Keys: vendor names (`vendor 1`, `vendor 2`, `vendor 3`)
        - Values: delivery charge
    upperLimits : dict
        The upper purchase limit at each vendor
        - Keys: vendor names (`vendor 1`, `vendor 2`, `vendor 3`)
        - Values: upper purchase limit
    lowerLimit : int
        The lower purchase limit
    M : int
        The M value used in the model
    demand : int
        The demand of computers
    """

    # Load a workbook from DATA_PATH
    inputBook = load_workbook(constant.DATA_PATH)

    # Find the sheet in which you want to write the solution
    inputSheet = inputBook[constant.INPUT_SHEET_NAME]

    # Read data from the inputSheet and create dictionaries
    prices = {}
    for vendorName in constant.VENDOR_NAMES:
        rowIndex = constant.INPUT_PRICE_START_ROW + constant.VENDOR_NAMES.index(vendorName)
        priceValue = inputSheet.cell(rowIndex, constant.INPUT_PRICE_START_COL).value
        prices[vendorName] = priceValue

    deliveryCharges = {}
    for vendorName in constant.VENDOR_NAMES:
        rowIndex = constant.INPUT_DELIVERY_CHARGE_START_ROW + constant.VENDOR_NAMES.index(vendorName)
        chargeValue = inputSheet.cell(rowIndex, constant.INPUT_DELIVERY_CHARGE_START_COL).value
        deliveryCharges[vendorName] = chargeValue

    upperLimits = {}
    for vendorName in constant.VENDOR_NAMES:
        rowIndex = constant.INPUT_UPPER_PURCHASE_LIMIT_START_ROW + constant.VENDOR_NAMES.index(vendorName)
        limitValue = inputSheet.cell(rowIndex, constant.INPUT_UPPER_PURCHASE_LIMIT_START_COL).value
        upperLimits[vendorName] = limitValue

    lowerLimit = inputSheet.cell(constant.INPUT_LOWER_PURCHASE_LIMIT_ROW, constant.INPUT_LOWER_PURCHASE_LIMIT_COL).value
    M = inputSheet.cell(constant.INPUT_M_ROW, constant.INPUT_M_COL).value
    demand = inputSheet.cell(constant.INPUT_DEMAND_ROW, constant.INPUT_DEMAND_COL).value

    return prices, deliveryCharges, upperLimits, lowerLimit, M, demand


def writeDataOpenpyxl(soln, objVal) -> None:
    """
    Write the solution back to the Excel file using openpyxl.

    Parameters
    ----------
    soln : dict
        The optimal solutions
        - Keys: variable names
        - Values: optimal decision variable values
    objVal : float
        The optimal objective function value
    """
    # Load a workbook from DATA_PATH
    outputBook = load_workbook(constant.DATA_PATH)

    # Find the sheet to write the solution
    outputSheet = outputBook.create_sheet(title=constant.OUTPUT_SHEET_NAME)

    # Write the optimal solutions to the outputSheet
    for i, vendor in enumerate(constant.VENDOR_NAMES):
        rowIndex = constant.OUTPUT_WHETHER_TO_PURCHASE_START_ROW + i
        colIndex = constant.OUTPUT_WHETHER_TO_PURCHASE_START_COL - 1
        outputSheet.cell(rowIndex, colIndex, constant.WHETHER_TO_PURCHASE_PREFIX + vendor)

        rowIndex = constant.OUTPUT_WHETHER_TO_PURCHASE_START_ROW + i
        colIndex = constant.OUTPUT_WHETHER_TO_PURCHASE_START_COL
        outputSheet.cell(rowIndex, colIndex, soln[constant.WHETHER_TO_PURCHASE_PREFIX + vendor])

        rowIndex = constant.OUTPUT_PURCHASE_NUMBER_START_ROW + i
        colIndex = constant.OUTPUT_PURCHASE_NUMBER_START_COL - 1
        outputSheet.cell(rowIndex, colIndex, constant.PURCHASE_NUMBER_PREFIX + vendor)

        rowIndex = constant.OUTPUT_PURCHASE_NUMBER_START_ROW + i
        colIndex = constant.OUTPUT_PURCHASE_NUMBER_START_COL
        outputSheet.cell(rowIndex, colIndex, soln[constant.PURCHASE_NUMBER_PREFIX + vendor])

    outputSheet.cell(constant.OUTPUT_COST_ROW, constant.OUTPUT_COST_COL - 1, constant.OUTPUT_COST_LABEL)
    outputSheet.cell(constant.OUTPUT_COST_ROW, constant.OUTPUT_COST_COL, objVal)

    outputSheet.column_dimensions[get_column_letter(constant.OUTPUT_COST_COL - 1)].width = constant.OUTPUT_LABEL_WIDTH

    # Save the workbook
    outputBook.save(constant.DATA_PATH)
