"""
Wyndor Production Planning Optimization Main Program
"""

from io_openpyxl import readDataOpenpyxl, writeDataOpenpyxl
from model import formulateModel, solveModel, getOptimalSolution, getOptimalDualSolution, saveModel, readModel

import constant


def main():
    """
    Main function
    """

    #
    # Step 1: Formulate the LP model.
    #

    # Option 1) Read data from the Excel file using openpyxl, then formulate the LP model.

    # Read data.
    prices, deliveryCharges, upperLimits, lowerLimit, M, demand = readDataOpenpyxl()

    # Formulate the LP model.
    model = formulateModel(prices, deliveryCharges, upperLimits, lowerLimit, M, demand)

    #
    # Optional: Save the LP model to an LP or an MPS file.
    #

    # Save the model.
    saveModel(model, constant.MPS_PATH)
    saveModel(model, constant.LP_PATH)

    #
    # Step 2: Solve the LP model.
    #

    solveModel(model)
    soln, objVal = getOptimalSolution(model)

    #
    # Optional: Extract dual variables.
    #

    # dualVariables = getOptimalDualSolution(model)

    #
    # Step 3: Write the solution to the Excel file.
    #

    # Option 1) Use openpyxl
    writeDataOpenpyxl(soln, objVal)

    # Option 2) Use pandas
    # writeDataPandas(soln, objVal)


if __name__ == "__main__":
    main()
