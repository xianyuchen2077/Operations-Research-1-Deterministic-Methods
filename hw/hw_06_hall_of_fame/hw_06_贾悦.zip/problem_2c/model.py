"""
Formulate and solve the Tatham Example using Gurobi.
"""

import gurobipy as grb

import constant


def formulateModel(delivery_charge, computer_charge, max_amount, min_amount, total_need) -> grb.Model:
    """
    Formulate a Gurobi model based on the computer purchasing problem's data.

    Parameters
    ----------
    delivery_charge : dict
        Delivery charge for each vendor.
        - Keys: vendor index
        - Values: delivery charge
    computer_charge : dict
        Computer unit cost for each vendor.
        - Keys: vendor index
        - Values: computer charge
    max_amount : dict
        Maximum purchase amount for each vendor.
        - Keys: vendor index
        - Values: maximum amount
    min_amount : dict
        Minimum purchase amount for each vendor.
        - Keys: vendor index
        - Values: minimum amount
    total_need : dict
        Total number of computers needed.
        - Key: "Total_Need"
        - Values: total number

    Returns
    -------
    model : grb.Model
        The formulated Gurobi model.
    """

    # Create a new model
    model = grb.Model(constant.MODEL_NAME)

    # Define decision variables
    # Pay attention to the change in variable type: BINARY rather than CONTINUOUS
    purchase_amount = {}  # Integer variables for number of computers
    purchase_decision = {}  # Binary variables for purchase decision
    
    for i in range(len(constant.VENDOR_NAMES)):
        purchase_amount[constant.VENDOR_NAMES[i]] = model.addVar(vtype=grb.GRB.INTEGER, 
                                                    name=constant.PURCHASE_AMOUNT_NAMES[i],
                                                    lb=0)  # Non-negative
        
        purchase_decision[constant.VENDOR_NAMES[i]] = model.addVar(vtype=grb.GRB.BINARY,
                                                      name=constant.PURCHASE_DECISION_NAMES[i])

    # Define the objective function
    objExpr = grb.LinExpr()
    for vendor_name in constant.VENDOR_NAMES:
        objExpr += computer_charge[vendor_name] * purchase_amount[vendor_name] + delivery_charge[vendor_name] * purchase_decision[vendor_name]
    
    model.setObjective(objExpr, grb.GRB.MINIMIZE)

    # Define the constraints
    
    # 1. Total need constraint
    lhsExpr = grb.LinExpr()
    for vendor_name in constant.VENDOR_NAMES:
        lhsExpr += purchase_amount[vendor_name]
    model.addConstr(lhsExpr == total_need[constant.TOTAL_NEED_NAME], name=constant.TOTAL_NEED_NAME)

    # 2. Big-M constraints for capacity limits (upper bounds)
    for i in range(len(constant.VENDOR_NAMES)):
        # purchase_amount_i <= max_amount_i * purchase_decision_i
        model.addConstr(purchase_amount[constant.VENDOR_NAMES[i]] <= max_amount[constant.VENDOR_NAMES[i]] * purchase_decision[constant.VENDOR_NAMES[i]], name=constant.MAXIMUM_CONSTRAINT_NAMES[i])

    # 3. Big-M constraints for minimum order (lower bounds)
    for i in range(len(constant.VENDOR_NAMES)):
        # purchase_amount_i >= min_amount_i * purchase_decision_i
        model.addConstr(purchase_amount[constant.VENDOR_NAMES[i]] >= min_amount[constant.VENDOR_NAMES[i]] * purchase_decision[constant.VENDOR_NAMES[i]], name=constant.MINIMUM_CONSTRAINT_NAMES[i])

    # Return the model
    return model


def solveModel(model) -> None:
    """
    Optimize the given Gurobi model.

    Parameters
    ----------
    model : gurobipy.Model
        The Gurobi model to be optimized

    """
    model.optimize()


def getOptimalSolution(model) -> tuple[dict, dict, float]:
    """
    Get the optimal solution and objective value of the optimized Gurobi model.

    Parameters
    ----------
    model : gurobipy.Model
        The Gurobi model to be optimized

    Returns
    -------
    purchase_amount_soln : dict
        Optimal x_i values (number of computers)
    purchase_decision_soln : dict
        Optimal y_i values (binary purchase decisions)
    objVal : float
        The optimal objective function value (total cost)
    """
    purchase_amount_soln = {}
    purchase_decision_soln = {}
    
    for var in model.getVars():
        var_name = var.VarName
        var_value = var.X
        
        if var_name in constant.PURCHASE_AMOUNT_NAMES:
            purchase_amount_soln[var_name] = var_value
        elif var_name in constant.PURCHASE_DECISION_NAMES:
            purchase_decision_soln[var_name] = var_value

    objVal = model.objVal

    # Print the optimal solutions and objective function value.
    print("\nThe optimal solutions:")
    for i in range(len(constant.VENDOR_NAMES)):
        print(f"  {constant.VENDOR_NAMES[i]}:")
        print(f"    {constant.DECISION_TYPE[0]}: {round(purchase_decision_soln[constant.PURCHASE_DECISION_NAMES[i]])}")
        if round(purchase_decision_soln[constant.PURCHASE_DECISION_NAMES[i]]):
            print(f"    {constant.DECISION_TYPE[1]}: {round(purchase_amount_soln[constant.PURCHASE_AMOUNT_NAMES[i]])}")
    
    print(f"The optimal objective function value: {objVal}\n")


    return purchase_amount_soln, purchase_decision_soln, objVal


def readModel(filePath) -> grb.Model:
    """
    Load a Gurobi model from a MPS or LP file.

    Parameters
    ----------
    filePath : str
        The path to the file to load the model from

    Returns
    -------
    model : gurobipy.Model
        The loaded Gurobi model
    """
    model = grb.read(filePath)

    return model


def saveModel(model, filePath) -> None:
    """
    Save the given Gurobi model to a file, either in MPS or LP format.

    Parameters
    ----------
    model : gurobipy.Model
        The Gurobi model to be saved
    filePath : str
        The path to the file to save the model to
    """
    model.write(filePath)
