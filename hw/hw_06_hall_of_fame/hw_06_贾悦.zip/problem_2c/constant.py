"""
Constants
"""

# Data file path and worksheet name
DATA_PATH = "../problem_2b.xlsx"
SHEET_NAME = "Solution_Gurobi"

LP_PATH = "./instance/state_univ.lp"
MPS_PATH = "./instance/state_univ.mps"

# Delivery charge data location (3 vendors)
INPUT_DELIVERY_CHARGE_ROW = 3
INPUT_DELIVERY_CHARGE_START_COL = 2

# Computer charge data location (3 vendors)
INPUT_COMPUTER_CHARGE_ROW = 4
INPUT_COMPUTER_CHARGE_START_COL = 2

# Maximum purchase amount data location (3 vendors)
INPUT_MAX_AMOUNT_ROW = 5
INPUT_MAX_AMOUNT_START_COL = 2

# Minimum purchase amount data location (3 vendors)
INPUT_MIN_AMOUNT_ROW = 6
INPUT_MIN_AMOUNT_START_COL = 2

# Total need data location
INPUT_TOTAL_NEED_ROW = 14
INPUT_TOTAL_NEED_COL = 2

# Output result location
OUTPUT_PURCHASE_DECISION_ROW = 10
OUTPUT_PURCHASE_DECISION_COL = 2

OUTPUT_PURCHASE_AMOUNT_ROW = 11
OUTPUT_PURCHASE_AMOUNT_COL = 2

OUTPUT_TOTAL_COST_ROW = 17
OUTPUT_TOTAL_COST_COL = 2

# Vendor names list
VENDOR_NAMES = ["Vendor_1", "Vendor_2", "Vendor_3"]

# Constraints names list
MAXIMUM_CONSTRAINT_NAMES = ["Max_Vendor_1", "Max_Vendor_2", "Max_Vendor_3"]
MINIMUM_CONSTRAINT_NAMES = ["Min_Vendor_1", "Min_Vendor_2", "Min_Vendor_3"]

# Decision Variable names list
PURCHASE_AMOUNT_NAMES = ["Purchase_Amount_Vendor_1", "Purchase_Amount_Vendor_2", "Purchase_Amount_Vendor_3"]
PURCHASE_DECISION_NAMES = ["Purchase_Decision_Vendor_1", "Purchase_Decision_Vendor_2", "Purchase_Decision_Vendor_3"]

# Total need name
TOTAL_NEED_NAME = "Total_Need"

# Model name
MODEL_NAME = "Computer_Purchasing"

# Keys for printing in console
DECISION_TYPE = ["Purchase or not", "Purchase Amount"]