"""
Reading from and writing to an Excel file using openpyxl.
"""

from openpyxl import load_workbook

import constant


def readDataOpenpyxl() -> tuple[dict, dict, dict, dict, dict]:
    """Read data from an Excel file using openpyxl.
    
    Returns
    -------
    delivery_charge : dict
        Delivery charge for each vendor.
        - Keys: vendor index
        - Values: delivery charge
    computer_charge : dict
        Computer charge for each vendor.
        - Keys: vendor index
        - Values: computer charge
    max_amount : dict
        Maximum purchase amount for each vendor.
        - Keys: vendor index
        - Values: max amount of purchase
    min_amount : dict
        Minimum purchase amount for each vendor.
        - Keys: vendor index
        - Values: min amount of purchase
    total_need : dict
        Total number of computers needed.
        - Key: "Total_Need"
        - Values: total number
    """

    # Load a workbook from DATA_PATH
    inputBook = load_workbook(constant.DATA_PATH)

    # Find the sheet in which you want to read data
    inputSheet = inputBook[constant.SHEET_NAME]

    # Read data from the inputSheet and create dictionaries
    delivery_charge = {}
    for i, vendor_name in enumerate(constant.VENDOR_NAMES):
        colIndex = constant.INPUT_DELIVERY_CHARGE_START_COL + i
        delivery_charge_value = inputSheet.cell(constant.INPUT_DELIVERY_CHARGE_ROW, colIndex).value
        delivery_charge[vendor_name] = float(delivery_charge_value)

    computer_charge = {}
    for i, vendor_name in enumerate(constant.VENDOR_NAMES):
        colIndex = constant.INPUT_COMPUTER_CHARGE_START_COL + i
        computer_charge_value = inputSheet.cell(constant.INPUT_COMPUTER_CHARGE_ROW, colIndex).value
        computer_charge[vendor_name] = computer_charge_value

    max_amount = {}
    for i, vendor_name in enumerate(constant.VENDOR_NAMES):
        colIndex = constant.INPUT_MAX_AMOUNT_START_COL + i
        max_amount_value = inputSheet.cell(constant.INPUT_MAX_AMOUNT_ROW, colIndex).value
        max_amount[vendor_name] = max_amount_value
    
    min_amount = {}
    for i, vendor_name in enumerate(constant.VENDOR_NAMES):
        colIndex = constant.INPUT_MIN_AMOUNT_START_COL + i
        min_amount_value = inputSheet.cell(constant.INPUT_MIN_AMOUNT_ROW, colIndex).value
        min_amount[vendor_name] = min_amount_value

    total_need = {}
    total_need[constant.TOTAL_NEED_NAME] = inputSheet.cell(constant.INPUT_TOTAL_NEED_ROW, constant.INPUT_TOTAL_NEED_COL).value
    
    return delivery_charge, computer_charge, max_amount, min_amount, total_need


def writeDataOpenpyxl(purchase_decision_soln, purchase_amount_soln, objVal) -> None:
    """
    Write the solution back to the Excel file using openpyxl.
    
    Parameters
    ----------
    purchase_decision_soln : dict
        Purchase decisions for each vendor.
        - Keys: vendor index
        - Values: purchase decision for each vendor (0 or 1)
    purchase_amount_soln : dict
        Number of computers purchased from each vendor.
        - Keys: vendor index
        - Values: purchase amount (integer)
    objVal : float
        The total cost achieved.
    """

    # Load a workbook from DATA_PATH
    outputBook = load_workbook(constant.DATA_PATH)

    # Find the sheet to write the solution
    outputSheet = outputBook[constant.SHEET_NAME]

    # Write purchase decision values
    for i, vendor_name in enumerate(constant.PURCHASE_DECISION_NAMES):
        colIndex = constant.OUTPUT_PURCHASE_DECISION_COL + i
        outputSheet.cell(constant.OUTPUT_PURCHASE_DECISION_ROW, colIndex).value = purchase_decision_soln[vendor_name]
    
    # Write purchase amount values
    for i, vendor_name in enumerate(constant.PURCHASE_AMOUNT_NAMES):
        colIndex = constant.OUTPUT_PURCHASE_AMOUNT_COL + i
        outputSheet.cell(constant.OUTPUT_PURCHASE_AMOUNT_ROW, colIndex).value = purchase_amount_soln[vendor_name]

    # Write total cost
    outputSheet.cell(constant.OUTPUT_TOTAL_COST_ROW, constant.OUTPUT_TOTAL_COST_COL).value = objVal

    # Save the workbook to DATA_PATH
    outputBook.save(constant.DATA_PATH)
