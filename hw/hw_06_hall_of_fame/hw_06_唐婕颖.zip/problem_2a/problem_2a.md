**Data:**
$I=\{\text{vendor 1,vendor 2,vendor 3}\}$

$c_i=\text{unit cost per computer from vendor} i \in I $

$d_i=\text{fixed delivery charge from vendor} i \in I $

$m_i=\text{maximun supply from vendor} i \in I $

$L=\text{minimum order quantity if ordering from a vendor}$

$N=\text{total number of computers the university must purchase}$

Parameter Values:

$c_1=500, c_2=350, c_3=250$

$d_1=5000, d_2=4000, d_3=6000$

$m_1=500, m_2=900, m_3=400$

$L=200$

$N=1100$

---
**Decision variables**
$x_i =
\begin{cases}
1, & \text{if we order from vendor } i \\
0, & \text{otherwise}
\end{cases}
$
$y_i = \text{number of computers to purchase from vendor } i \in I$

---
**Objective Function:**

The objective is to minimize the total cost, which consists of the variable purchasing costs and the fixed delivery charges:
$$
\text{Minimize} \quad Z = \sum_{i \in I} c_i y_i + \sum_{i \in I} d_i x_i
$$

---
**Constraints:**
1. **Total Demand Constraint:**
$$ \sum_{i \in I} y_i = N $$
2. **Minimum Order Quantity Constraints:**
$$ y_i \geq L \cdot x_i \quad \forall i \in I $$
3. **Maximum supply and Logical Linking Constraints:**
$$y_i \leq m_i \quad \forall i$$
$$ y_i \leq m_i \cdot x_i \quad \forall i \in I $$ 
$y_i \leq m_i \quad \forall i$ is **redundant** because $x_i \leq m_i y_i$ already enforces the capacity limit when $y_i = 1$ and forces $x_i = 0$ when $y_i = 0$.  
Keep only
 $$y_i \leq m_i x_i \quad \forall i$$ in the final model.
1. **Variable Domain Constraints:**
$$x_i \quad binary \quad  \forall i \in I $$  
$$y_i \geq 0 \quad and\quad integer \quad \forall i \in I$$

---
**Complete IP model**
Minimize
\[
Z = \sum_{i \in I} c_i y_i + \sum_{i \in I} d_i x_i
\]

Subject to
\[
\begin{aligned}
& \sum_{i \in I} y_i = N \\
& y_i \geq L \cdot x_i, \quad \forall i \in I \\
& y_i \leq m_i \cdot x_i, \quad \forall i \in I \\
& x_i \quad \text{binary}, \quad \forall i \in I \\
& y_i \geq 0 \ \text{and integer}, \quad \forall i \in I
\end{aligned}
\]

