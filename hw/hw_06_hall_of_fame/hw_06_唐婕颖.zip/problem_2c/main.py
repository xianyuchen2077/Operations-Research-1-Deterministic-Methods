"""
Main entry point – State University computer purchasing
"""

from io_pandas import readDataPandas, writeDataPandas
from model import formulateModel, solveModel, getOptimalSolution, saveModel
import constant


def main():
    """
    Main function – read → build → solve → write (pandas)
    """

    # ---- 1. Data ingestion ----
    unitPrice, fixedCost, maxSupply, needed, minOrder = readDataPandas()


    # ---- 2. Model construction ----
    model = formulateModel(unitPrice, fixedCost, maxSupply, needed, minOrder)

    # ---- 3. Export LP (optional) ----
    saveModel(model, constant.LP_PATH)

    # ---- 4. Optimization ----
    solveModel(model)
    purchaseAny, unitsPurch, totalCost = getOptimalSolution(model)

    # ---- 5. Post-processing ----
    totalUnitCost     = sum(unitPrice[v] * unitsPurch[v] for v in constant.VENDOR_NAMES)
    totalDeliveryCost = sum(fixedCost[v] * purchaseAny[v] for v in constant.VENDOR_NAMES)

    # ---- 6. Report results ----
    writeDataPandas(purchaseAny, unitsPurch,
                    totalUnitCost, totalDeliveryCost, totalCost,
                    minOrder)


if __name__ == "__main__":
    main()
