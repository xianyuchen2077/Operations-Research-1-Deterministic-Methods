"""
Reading / writing Excel
"""

import pandas as pd
import openpyxl
import constant


def readDataPandas() -> tuple[dict, dict, dict, int, int]:
    """
    Read exogenous parameters from Sheet1.

    Returns
    -------
    unitPrice : dict – unit price per computer   (key = vendor name)
    fixedCost : dict – fixed delivery cost       (key = vendor name)
    maxSupply : dict – maximum supply            (key = vendor name)
    needed    : int  – total computers required
    minOrder  : int  – minimum order size if vendor is used
    """
    data = pd.read_excel(constant.DATA_PATH,
                         sheet_name=constant.SHEET_NAME,
                         header=None)

    def _colDict(startRow, names):
        """Return a dict extracted from one row (starting at column B)."""
        row = startRow - 1
        return {name: data.iloc[row, 1 + idx]
                for idx, name in enumerate(names)}

    unitPrice = _colDict(constant.INPUT_UNIT_PRICE_START_ROW,
                         constant.VENDOR_NAMES)
    fixedCost = _colDict(constant.INPUT_FIXED_COST_START_ROW,
                         constant.VENDOR_NAMES)
    maxSupply = _colDict(constant.INPUT_MAX_SUPPLY_START_ROW,
                         constant.VENDOR_NAMES)

    needed   = data.iloc[constant.INPUT_NEEDED_START_ROW - 1,
                         constant.INPUT_NEEDED_START_COL - 1]
    minOrder = data.iloc[constant.INPUT_MIN_ORDER_ROW - 1,
                         constant.INPUT_MIN_ORDER_COL - 1]

    return unitPrice, fixedCost, maxSupply, int(needed), int(minOrder)


def writeDataPandas(purchaseAny, unitsPurch,
                    totalUnitCost, totalDeliveryCost, totalCost,
                    minOrder) -> None:
    """
    Write the optimal solution into a new sheet 'Solution_Gurobi'
    while preserving all original formatting.
    """

    # 1. Open workbook (keep formatting)
    wb = openpyxl.load_workbook(constant.DATA_PATH)
    src = wb[constant.SHEET_NAME]

    # 2. Remove existing target sheet, then copy template
    if constant.RESULT_SHEET_NAME in wb.sheetnames:
        wb.remove(wb[constant.RESULT_SHEET_NAME])
    dst = wb.copy_worksheet(src)
    dst.title = constant.RESULT_SHEET_NAME

    # 3. Decision variables
    row, col = constant.OUTPUT_PURCHASE_ANY_START_ROW, constant.OUTPUT_PURCHASE_ANY_START_COL
    for idx, v in enumerate(constant.VENDOR_NAMES):
        dst.cell(row=row, column=col + idx, value=purchaseAny[v])
        dst.cell(row=row + 1, column=col + idx, value=unitsPurch[v])   # units purchased

    # 4. Logical upper limit  (= units purchased)
    row, col = constant.OUTPUT_LOGICAL_UPPER_START_ROW, constant.OUTPUT_LOGICAL_UPPER_START_COL
    for idx, v in enumerate(constant.VENDOR_NAMES):
        dst.cell(row=row, column=col + idx, value=unitsPurch[v])

    # 5. Logical lower limit  (= minOrder * purchaseAny)
    row, col = constant.OUTPUT_LOGICAL_LOWER_START_ROW, constant.OUTPUT_LOGICAL_LOWER_START_COL
    for idx, v in enumerate(constant.VENDOR_NAMES):
        dst.cell(row=row, column=col + idx, value=minOrder * purchaseAny[v])

    # 6. Quantity used (total units bought)
    dst.cell(row=constant.OUTPUT_QUANTITY_USED_START_ROW,
             column=constant.OUTPUT_QUANTITY_USED_START_COL,
             value=sum(unitsPurch[v] for v in constant.VENDOR_NAMES))

    # 7. Cost summary
    dst.cell(row=constant.OUTPUT_TOTAL_UNIT_COST_ROW,
             column=constant.OUTPUT_TOTAL_UNIT_COST_COL, value=totalUnitCost)
    dst.cell(row=constant.OUTPUT_TOTAL_DELIVERY_COST_ROW,
             column=constant.OUTPUT_TOTAL_DELIVERY_COST_COL, value=totalDeliveryCost)
    dst.cell(row=constant.OUTPUT_TOTAL_COST_ROW,
             column=constant.OUTPUT_TOTAL_COST_COL, value=totalCost)

    # 8. Save
    wb.save(constant.DATA_PATH)