"""
Integer-linear model for State University computer purchasing
"""

import gurobipy as grb
import constant


def formulateModel(unitPrice: dict, fixedCost: dict, maxSupply: dict,
                   needed: int, minOrder: int) -> grb.Model:
    """
    Build an IP model that minimizes total cost (unit cost + fixed delivery)
    subject to demand, supply and minimum-order constraints.

    Parameters
    ----------
    unitPrice   : dict – unit price per computer (key = vendor name)
    fixedCost   : dict – fixed delivery cost (key = vendor name)
    maxSupply   : dict – maximum available supply (key = vendor name)
    needed      : int  – total computers required
    minOrder    : int  – minimum order size if a vendor is used

    Returns
    -------
    model : grb.Model
        Constructed Gurobi model
    """
    model = grb.Model(constant.MODEL_NAME)

    # Decision variables
    purchaseAny = {}          # 1 if vendor v is used, 0 otherwise
    unitsPurch = {}           # integer: units bought from vendor v
    for v in constant.VENDOR_NAMES:
        purchaseAny[v] = model.addVar(vtype=grb.GRB.BINARY,
                                      name=f"purchaseAny_{v}")
        unitsPurch[v] = model.addVar(lb=0,
                                     vtype=grb.GRB.INTEGER,
                                     name=f"unitsPurch_{v}")

    # Objective: minimise total unit cost + total fixed delivery cost
    obj = grb.quicksum(unitPrice[v] * unitsPurch[v] +
                       fixedCost[v] * purchaseAny[v]
                       for v in constant.VENDOR_NAMES)
    model.setObjective(obj, grb.GRB.MINIMIZE)

    # Constraints
    # 1. Demand satisfaction
    model.addConstr(grb.quicksum(unitsPurch[v] for v in constant.VENDOR_NAMES) == needed,
                    name="Demand")

    # 2. Supply limit, minimum-order and linking constraints
    for v in constant.VENDOR_NAMES:
        model.addConstr(unitsPurch[v] <= maxSupply[v], name=f"MaxSupply_{v}")
        model.addConstr(unitsPurch[v] >= minOrder * purchaseAny[v], name=f"MinOrder_{v}")
        model.addConstr(unitsPurch[v] <= maxSupply[v] * purchaseAny[v], name=f"Link_{v}")

    return model


def solveModel(model: grb.Model) -> None:
    """Solve the model."""
    model.optimize()


def getOptimalSolution(model: grb.Model) -> tuple[dict, dict, float]:
    """
    Retrieve optimal solution and total cost.

    Returns
    -------
    purchaseAny : dict – 1/0 whether vendor is used
    unitsPurch  : dict – integer units purchased from each vendor
    totalCost   : float – optimal objective value
    """
    purchaseAny = {v: round(model.getVarByName(f"purchaseAny_{v}").X)
                   for v in constant.VENDOR_NAMES}
    unitsPurch = {v: int(model.getVarByName(f"unitsPurch_{v}").X)
                  for v in constant.VENDOR_NAMES}
    totalCost = model.objVal

    print("\nOptimal solution (integer units):")
    for v in constant.VENDOR_NAMES:
        print(f"  {v}: purchaseAny={purchaseAny[v]}, unitsPurch={unitsPurch[v]}")
    print(f"  Total cost = {totalCost:.2f}\n")

    return purchaseAny, unitsPurch, totalCost


# Utility functions
def readModel(filePath: str) -> grb.Model:
    return grb.read(filePath)


def saveModel(model: grb.Model, filePath: str) -> None:
    model.write(filePath)