"""
Constants
"""

# ------------------------------------------------------------------
# 1. File paths
# ------------------------------------------------------------------
DATA_PATH         = "./data/2_b.xlsx"      # input data workbook
SHEET_NAME        = "Sheet1"               # source worksheet

LP_PATH           = "./instance/computer.lp"   # optional: export LP model
MPS_PATH          = "./instance/computer.mps"  # optional: export MPS model

RESULT_SHEET_NAME = "Solution_Gurobi"      # target worksheet for results

# ------------------------------------------------------------------
# 2. Input data ranges (Excel rows/columns start at 1)
# ------------------------------------------------------------------
# 2.1 Unit prices
INPUT_UNIT_PRICE_START_ROW = 4
INPUT_UNIT_PRICE_START_COL = 2          # column B

# 2.2 Fixed delivery costs
INPUT_FIXED_COST_START_ROW = 5
INPUT_FIXED_COST_START_COL = 2

# 2.3 Maximum supply
INPUT_MAX_SUPPLY_START_ROW = 6
INPUT_MAX_SUPPLY_START_COL = 2

# 2.4 Minimum order size (global constant in cell D8)
INPUT_MIN_ORDER_ROW = 8
INPUT_MIN_ORDER_COL = 4

# 2.5 Total demand
INPUT_NEEDED_START_ROW = 23
INPUT_NEEDED_START_COL = 4              # column D

# ------------------------------------------------------------------
# 3. Output ranges (written to Solution_Gurobi)
# ------------------------------------------------------------------
# Logical limits
OUTPUT_LOGICAL_UPPER_START_ROW = 16
OUTPUT_LOGICAL_UPPER_START_COL = 2

OUTPUT_LOGICAL_LOWER_START_ROW = 18
OUTPUT_LOGICAL_LOWER_START_COL = 2

# Decision variables
OUTPUT_PURCHASE_ANY_START_ROW = 13       # 0/1 purchase flag
OUTPUT_PURCHASE_ANY_START_COL = 2

OUTPUT_UNITS_PURCHASED_START_ROW = 14    # integer units purchased
OUTPUT_UNITS_PURCHASED_START_COL = 2

# Cost summary
OUTPUT_TOTAL_UNIT_COST_ROW = 26          # total variable cost
OUTPUT_TOTAL_UNIT_COST_COL = 2

OUTPUT_TOTAL_DELIVERY_COST_ROW = 27      # total fixed delivery cost
OUTPUT_TOTAL_DELIVERY_COST_COL = 2

OUTPUT_TOTAL_COST_ROW = 28               # total cost
OUTPUT_TOTAL_COST_COL = 2

# Quantity used (total units)
OUTPUT_QUANTITY_USED_START_ROW = 23
OUTPUT_QUANTITY_USED_START_COL = 2

# ------------------------------------------------------------------
# 4. Model entities
# ------------------------------------------------------------------
VENDOR_NAMES = ["Vendor_1", "Vendor_2", "Vendor_3"]
MODEL_NAME   = "StateUniversity_ComputerPurchasing"