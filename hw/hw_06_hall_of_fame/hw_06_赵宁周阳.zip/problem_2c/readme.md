#### 1 Create environment

`cd` into this directory `problem_2c`, enter the following command (only in Windows OS)

```bash
python -m venv .venv
.venv\Scripts\activate
```

#### 2 Install packages

After activate the environment, enter the following command (only in Windows OS)

```bash
pip install -r requirements.txt
```

This will install `openpyxl` and `gurobipy`

#### 3 Run the code

In this directory `problem_2c`, enter the following command (only in Windows OS)

```bash
python main.py
```

Note: Don't open the `problem_2b.xlsx` until the programme is running over, otherwise it would lead to an error!