from io_openpyxl import readDataOpenpyxl, writeSolutionOpenpyxl
from model import formulateModel, getOptimalSolution
import constant

def main():
    cost_computer, cost_deliver, constraints_max, constraints_min, required_num = readDataOpenpyxl()

    model = formulateModel(cost_computer, cost_deliver, constraints_max, constraints_min, required_num)
    model.optimize()
    (solution_whether, solution_num), total_cost = getOptimalSolution(model)

    print ("Optimal Solution:")
    for vendor in constant.NAME_VENDOR:
        print(f"  whether {vendor}: {solution_whether[vendor]}") 
        print(f"  num {vendor}: {solution_num[vendor]}")
    print(f"Total Cost: ${total_cost}")

    writeSolutionOpenpyxl((solution_whether, solution_num), total_cost)
if __name__ == "__main__":
    main()