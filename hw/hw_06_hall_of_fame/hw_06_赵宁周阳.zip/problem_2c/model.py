import gurobipy as gp
from gurobipy import GRB
import constant

def formulateModel(cost_computer: dict, cost_deliver: dict, constraints_max: dict, constraints_min: dict, required_num: int) -> gp.Model:
    model = gp.Model(constant.NAME_MODEL)

    x = {}
    for vendor in constant.NAME_VENDOR:
        x[vendor] = model.addVar(name=vendor+"_whether", vtype=GRB.BINARY, lb=0)

    y = {}
    for vendor in constant.NAME_VENDOR:
        y[vendor] = model.addVar(name=vendor+"_num", vtype=GRB.INTEGER, lb=0)

    z = gp.quicksum(y[vendor]*cost_computer[vendor] + x[vendor]*cost_deliver[vendor] for vendor in constant.NAME_VENDOR)
    model.setObjective(z, GRB.MINIMIZE)
    
    for vendor in constant.NAME_VENDOR:
        model.addConstr(y[vendor] <= constraints_max[vendor] * x[vendor], name=vendor+"_max_constrant")
        model.addConstr(y[vendor] >= constraints_min[vendor] * x[vendor], name=vendor+"_min_constrant")
    
    model.addConstr(gp.quicksum(y[vendor] for vendor in constant.NAME_VENDOR) == required_num, name="required_num_constrant")

    model.update()
    return model

def getOptimalSolution(model: gp.Model) -> tuple[dict[str, float], float]:
    solution_whether = {}
    for vendor in constant.NAME_VENDOR:
        var = model.getVarByName(vendor+"_whether")
        solution_whether[vendor] = var.x

    solution_num = {}
    for vendor in constant.NAME_VENDOR:
        var = model.getVarByName(vendor+"_num")
        solution_num[vendor] = var.x

    total_cost = model.objVal 

    return (solution_whether, solution_num), total_cost