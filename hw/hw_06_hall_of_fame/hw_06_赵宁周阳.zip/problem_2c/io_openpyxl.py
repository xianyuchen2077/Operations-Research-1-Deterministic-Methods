from openpyxl import load_workbook
import constant

def readDataOpenpyxl() -> tuple[dict, dict, dict]:
    wb = load_workbook(filename=constant.MODEL_PATH, data_only=True)
    sheet = wb[constant.SHEET_NAME]

    cost_computer = {}
    for i in range(len(constant.NAME_VENDOR)):
        cost_computer[constant.NAME_VENDOR[i]] = sheet.cell(row=constant.INPUT_COST_COMPUTER_ROW, column=constant.INPUT_COST_COMPUTER_COL + i).value

    cost_deliver = {}
    for i in range(len(constant.NAME_VENDOR)):
        cost_deliver[constant.NAME_VENDOR[i]] = sheet.cell(row=constant.INPUT_COST_DELIVER_ROW, column=constant.INPUT_COST_DELIVER_COL + i).value

    constraints_max = {}
    for i in range(len(constant.NAME_VENDOR)):
        constraints_max[constant.NAME_VENDOR[i]] = sheet.cell(row=constant.INPUT_CONSTRANT_MAX_ROW, column=constant.INPUT_CONSTRANT_MAX_COL + i).value
        
    constraints_min = {}
    for i in range(len(constant.NAME_VENDOR)):
        constraints_min[constant.NAME_VENDOR[i]] = sheet.cell(row=constant.INPUT_CONSTRANT_MIN_ROW, column=constant.INPUT_CONSTRANT_MIN_COL + i).value
    
    required_num = sheet.cell(row=constant.INPUT_REQUIRED_NUM_ROW, column=constant.INPUT_REQUIRED_NUM_COL).value
    
    wb.close()
    return cost_computer, cost_deliver, constraints_max, constraints_min, required_num

def writeSolutionOpenpyxl(solution: tuple[dict, dict], total_cost: float) -> None:
    wb = load_workbook(filename=constant.MODEL_PATH)
    if "Solution_Gurobi" in wb.sheetnames:
        del wb["Solution_Gurobi"]
    sheet = wb.create_sheet(title="Solution_Gurobi")

    sheet.cell(row=1, column=1, value="Optimal Solution")
    sheet.cell(row=constant.OUTPUT_SOLUTION_BIN_ROW, column=1, value="Whether to purchase")
    sheet.cell(row=constant.OUTPUT_SOLUTION_NUM_ROW, column=1, value="Number purchased")
    sheet.cell(row=1, column=constant.OUTPUT_TOTAL_COST_COL, value="Total Cost")

    for i in range(len(constant.NAME_VENDOR)):
        sheet.cell(row=1, column=constant.OUTPUT_SOLUTION_BIN_COL + i, value=constant.NAME_VENDOR[i])
        sheet.cell(row=constant.OUTPUT_SOLUTION_BIN_ROW, column=constant.OUTPUT_SOLUTION_BIN_COL + i, value=solution[0][constant.NAME_VENDOR[i]])
        sheet.cell(row=constant.OUTPUT_SOLUTION_NUM_ROW, column=constant.OUTPUT_SOLUTION_NUM_COL + i, value=solution[1][constant.NAME_VENDOR[i]])

    sheet.cell(row=constant.OUTPUT_TOTAL_COST_ROW, column=constant.OUTPUT_TOTAL_COST_COL, value=total_cost).number_format = '$#,##0'

    wb.save(constant.MODEL_PATH)
    wb.close()