#### Data

$C_i = {\rm cost\space per\space computer\space from\space Vendor}\space i\in\{1,2,3\}$

$D_i = {\rm cost\space of\space delivery\space from\space Vendor}\space i\in\{1,2,3\}$

$R = {\rm total\space number\space of\space computers\space required}$

$M_i = {\rm the\space maximum\space number\space of\space computers\space from\space Vendor}\space i\in\{1,2,3\}$

$m = {\rm the\space minimum\space order\space of\space computers}$

#### Decisions

$x_i = 1({\rm if\space purchase\space computer\space from\space Vendor}\space i\in\{1,2,3\}),0({\rm otherwise})$

$y_i = {\rm the\space number\space of\space computer\space purchased\space from\space Vendor}\space i\in\{1,2,3\}$

#### Model

$\min\space \sum\limits_{i\in\{1,2,3\}}C_iy_i+\sum\limits_{i\in\{1,2,3\}}D_ix_i$
${\rm s.t.}\space\space\space \sum\limits_{i\in\{1,2,3\}}y_i = R$
$\space\space\space\space\space\space\space\space\space\space\space\space\space y_i\leq M_ix_i,\forall i\in\{1,2,3\}$
$\space\space\space\space\space\space\space\space\space\space\space\space\space y_i\geq mx_i,\forall i\in\{1,2,3\}$
$\space\space\space\space\space\space\space\space\space\space\space\space\space x_i\space{\rm binary},\forall i\in\{1,2,3\}$
$\space\space\space\space\space\space\space\space\space\space\space\space\space y_i\geq 0 \space{\rm and\space integer},\forall i\in\{1,2,3\}$

${\rm By\space inputting\space specific\space data\space, we\space get\space the\space following\space IP}$


$
\begin{array}{lrrrrrrrrrrrl}
\min        & 5000x_1  & + & 4000x_2 & + & 6000x_3 & + & 500y_1 & + & 350y_2 & + & 250y_3 &             \\
\text{s.t.} &          &   &         &   &         &   & y_1    & + & y_2    & + & y_3    & = 1100      \\
            & 500x_1   &   &         &   &         & - & y_1    &   &        &   &        & \geq 0      \\
            &          &   & 900x_2  &   &         &   &        & - & y_2    &   &        & \geq 0      \\
            &          &   &         &   & 400x_3  &   &        &   &        & - & y_3    & \geq 0      \\
            & 200x_1   &   &         &   &         & - & y_1    &   &        &   &        & \leq 0      \\
            &          &   & 200x_2  &   &         &   &        & - & y_2    &   &        & \leq 0      \\
            &          &   &         &   & 200x_3  &   &        &   &        & - & y_3    & \leq 0      \\
            &   x _1   &   &         &   &         &   &        &   &        &   &        & {\rm binary}\\
            &          &   & x_2     &   &         &   &        &   &        &   &        & {\rm binary}\\
            &          &   &         &   & x_3     &   &        &   &        &   &        & {\rm binary}\\
            &          &   &         &   &         &   & y_1    &   &        &   &        & \geq 0 \space{\rm and\space integer}\\
            &          &   &         &   &         &   &        &   & y_2    &   &        & \geq 0 \space{\rm and\space integer}\\
            &          &   &         &   &         &   &        &   &        &   & y_3    & \geq 0 \space{\rm and\space integer}\\
\end{array}
$

#### Explaination

##### objective function

$\sum\limits_{i\in\{1,2,3\}}C_iy_i+\sum\limits_{i\in\{1,2,3\}}D_ix_i\space{\rm is\space the\space total\space cost,\space so\space it\space should\space be\space minimize}$

##### constraints

$\sum\limits_{i\in\{1,2,3\}}y_i\space{\rm is\space the\space total\space number\space of\space computers\space purchased,\space so\space it\space must\space equal\space to}\space R$

${\rm if}\space x_i = 0,\space {\rm then\space must\space have\space the\space purchased\space number\space } y_i = 0.$
${\rm else}(x_i=1),\space {\rm then\space must\space have\space the\space purchased\space number\space } y_i \leq M_i({\rm the\space maximum\space number\space})$
${\rm and}\space y_i \geq m({\rm the\space minimum\space number\space}) $
${\rm so\space we\space have\space }y_i\leq M_ix_i\space{\rm and\space y_i\geq mx_i}$

##### variable definitions

${\rm because\space}x_i\space{\rm indicates\space whether\space to\space purchase\space from\space Vendor\space} i$
${\rm so\space we\space have\space}x_i\space {\rm binary}$

${\rm because\space}y_i\space{\rm indicates\space the\space number\space of\space computer\space purchased\space from\space Vendor\space} i$
${\rm so\space we\space have\space}y_i\geq 0 \space{\rm and\space integer}$