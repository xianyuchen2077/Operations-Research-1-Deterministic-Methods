### Simplex Method

#### Initialization

###### Canonical form

$\rm{max}\begin{bmatrix}4&2&4&0&0&0\\\end{bmatrix}\begin{bmatrix}x_1\\x_2\\x_3\\s_1\\s_2\\s_3\\\end{bmatrix}$

$\rm{s.t.}\begin{bmatrix}4&1&2&1&0&0\\2&5&3&0&1&0\\0&2&1&0&0&1\end{bmatrix}\begin{bmatrix}x_1\\x_2\\x_3\\s_1\\s_2\\s_3\\\end{bmatrix}=\begin{bmatrix}24\\30\\16\\\end{bmatrix},(x\geq0)$

###### Basis

$c_B^T=\begin{bmatrix}0&0&0\\\end{bmatrix}, c_N^T=\begin{bmatrix}4&2&4\\\end{bmatrix}$

$B=\begin{bmatrix}1&0&0\\0&1&0\\0&0&1\end{bmatrix},N=\begin{bmatrix}4&1&2\\2&5&3\\0&2&1\end{bmatrix},b=\begin{bmatrix}24\\30\\16\end{bmatrix}$

###### Basic and nonbasic variables

$B^{-1}=\begin{bmatrix}1&0&0\\0&1&0\\0&0&1\end{bmatrix}$

$x_B=\begin{bmatrix}s_1\\s_2\\s_3\end{bmatrix}=B^{-1}b=\begin{bmatrix}24\\30\\16\end{bmatrix},x_N=\begin{bmatrix}x_1\\x_2\\x_3\end{bmatrix}=\begin{bmatrix}0\\0\\0\end{bmatrix}$

#### Iteration 1

##### Step 1. Optimality check

###### Simplex multipliers

$\pi^T=c_B^TB^{-1}=\begin{bmatrix}0&0&0\\\end{bmatrix}\begin{bmatrix}1&0&0\\0&1&0\\0&0&1\end{bmatrix}=\begin{bmatrix}0&0&0\\\end{bmatrix}$

###### Reduced cost

$\bar{c}_N^T=c_N^T-c_B^TB^{-1}N=c_N^T-\pi^TN=\begin{bmatrix}4&2&4\\\end{bmatrix}-\begin{bmatrix}0&0&0\\\end{bmatrix}\begin{bmatrix}4&1&2\\2&5&3\\0&2&1\end{bmatrix}=\begin{bmatrix}4&2&4\\\end{bmatrix}$

###### Entering variables

$x_e=x_1$

###### Simplex direction

$d_N=\begin{bmatrix}1\\0\\0\end{bmatrix}$

##### Step 2. Minimum ratio test

###### Compute the simplex direction

$d_B^{(e)}=-B^{-1}a_e=-\begin{bmatrix}1&0&0\\0&1&0\\0&0&1\end{bmatrix}\begin{bmatrix}4\\2\\0\end{bmatrix}=\begin{bmatrix}-4\\-2\\0\end{bmatrix}$

###### Minimum ratio

$\lambda = \min \left\{-\dfrac{x_j}{d_j}:d_j < 0,j\in B\right\}=\min\left\{\dfrac{24}{4},\dfrac{30}{2}\right\}=6$

###### Leaving variables

$x_l=s_1$

##### Step 3. Update solution and basis

###### Update the basis

$c_B^T=\begin{bmatrix}4&0&0\\\end{bmatrix}, c_N^T=\begin{bmatrix}0&2&4\\\end{bmatrix}$

$B=\begin{bmatrix}4&0&0\\2&1&0\\0&0&1\end{bmatrix},N=\begin{bmatrix}1&1&2\\0&5&3\\0&2&1\end{bmatrix},b=\begin{bmatrix}24\\30\\16\end{bmatrix}$

###### Basic and nonbasic variables

$B^{-1}=\begin{bmatrix}1/4&0&0\\-1/2&1&0\\0&0&1\end{bmatrix}$

$x_B=\begin{bmatrix}x_1\\s_2\\s_3\end{bmatrix}=B^{-1}b=\begin{bmatrix}6\\18\\16\end{bmatrix},x_N=\begin{bmatrix}s_1\\x_2\\x_3\end{bmatrix}=\begin{bmatrix}0\\0\\0\end{bmatrix}$

#### Iteration 2

##### Step 1. Optimality check

###### Simplex multipliers

$\pi^T=c_B^TB^{-1}=\begin{bmatrix}4&0&0\\\end{bmatrix}\begin{bmatrix}1/4&0&0\\-1/2&1&0\\0&0&1\end{bmatrix}=\begin{bmatrix}1&0&0\\\end{bmatrix}$

###### Reduced cost

$\bar{c}_N^T=c_N^T-c_B^TB^{-1}N=c_N^T-\pi^TN=\begin{bmatrix}0&2&4\\\end{bmatrix}-\begin{bmatrix}1&0&0\\\end{bmatrix}\begin{bmatrix}1&1&2\\0&5&3\\0&2&1\end{bmatrix}=\begin{bmatrix}-1&1&2\\\end{bmatrix}$

###### Entering variables

$x_e=x_3$

###### Simplex direction

$d_N=\begin{bmatrix}0\\0\\1\end{bmatrix}$

##### Step 2. Minimum ratio test

###### Compute the simplex direction

$d_B^{(e)}=-B^{-1}a_e=-\begin{bmatrix}1/4&0&0\\-1/2&1&0\\0&0&1\end{bmatrix}\begin{bmatrix}2\\3\\1\end{bmatrix}=\begin{bmatrix}-1/2\\-2\\-1\end{bmatrix}$

###### Minimum ratio

$\lambda = \min \left\{-\dfrac{x_j}{d_j}:d_j < 0,j\in B\right\}=\min\left\{\dfrac{6}{1/2},\dfrac{18}{2},\dfrac{16}{1}\right\}=9$

###### Leaving variables

$x_l=s_2$

##### Step 3. Update solution and basis

###### Update the basis

$c_B^T=\begin{bmatrix}4&4&0\\\end{bmatrix}, c_N^T=\begin{bmatrix}0&2&0\\\end{bmatrix}$

$B=\begin{bmatrix}4&2&0\\2&3&0\\0&1&1\end{bmatrix},N=\begin{bmatrix}1&1&0\\0&5&1\\0&2&0\end{bmatrix},b=\begin{bmatrix}24\\30\\16\end{bmatrix}$

###### Basic and nonbasic variables

$B^{-1}=\begin{bmatrix}3/8&-1/4&0\\-1/4&1/2&0\\1/4&-1/2&1\end{bmatrix}$

$x_B=\begin{bmatrix}x_1\\x_3\\s_3\end{bmatrix}=B^{-1}b=\begin{bmatrix}3/2\\9\\7\end{bmatrix},x_N=\begin{bmatrix}s_1\\x_2\\s_2\end{bmatrix}=\begin{bmatrix}0\\0\\0\end{bmatrix}$

#### Iteration 3

##### Step 1. Optimality check

###### Simplex multipliers

$\pi^T=c_B^TB^{-1}=\begin{bmatrix}4&4&0\\\end{bmatrix}\begin{bmatrix}3/8&-1/4&0\\-1/4&1/2&0\\1/4&-1/2&1\end{bmatrix}=\begin{bmatrix}1/2&1&0\\\end{bmatrix}$

###### Reduced cost

$\bar{c}_N^T=c_N^T-c_B^TB^{-1}N=c_N^T-\pi^TN=\begin{bmatrix}0&2&0\\\end{bmatrix}-\begin{bmatrix}1/2&1&0\\\end{bmatrix}\begin{bmatrix}1&1&0\\0&5&1\\0&2&0\end{bmatrix}=\begin{bmatrix}-1/2&-7/2&-1\\\end{bmatrix}$

###### No improving directions $\to$ Optimal solution

$\begin{bmatrix}x_1\\x_2\\x_3\end{bmatrix}=\begin{bmatrix}1.5\\0\\9\end{bmatrix},\max\left\{4x_1+2x_2+4x_3\right\}=42$