### Tableau simplex method

#### Initialization

###### Canonical form

$\rm{max}\begin{bmatrix}4&2&4&0&0&0\\\end{bmatrix}\begin{bmatrix}x_1\\x_2\\x_3\\s_1\\s_2\\s_3\\\end{bmatrix}$

$\rm{s.t.}\begin{bmatrix}4&1&2&1&0&0\\2&5&3&0&1&0\\0&2&1&0&0&1\end{bmatrix}\begin{bmatrix}x_1\\x_2\\x_3\\s_1\\s_2\\s_3\\\end{bmatrix}=\begin{bmatrix}24\\30\\16\\\end{bmatrix},(x\geq0)$

###### Basis

$\begin{array}{c|cccccc|c}\rm{Basis}&x_1&x_2&x_3&s_1&s_2&s_3&\rm{RHS}\\\hline\rm{Row}\space0&-4&-2&-4&0&0&0&0\\\hline s_1&4&1&2&\textcolor{red}{1}&\textcolor{red}{0}&\textcolor{red}{0}&24\\s_2&2&5&3&\textcolor{red}{0}&\textcolor{red}{1}&\textcolor{red}{0}&30\\s_3&0&2&1&\textcolor{red}{0}&\textcolor{red}{0}&\textcolor{red}{1}&16\end{array}$

#### Iteration 1

##### Step 1. Optimality check

###### Reduced cost

$\begin{array}{c|cccccc|c}\rm{Basis}&x_1&x_2&x_3&s_1&s_2&s_3&\rm{RHS}\\\hline\rm{Row}\space0&\textcolor{red}{-4}&\textcolor{red}{-2}&\textcolor{red}{-4}&0&0&0&0\\\hline s_1&4&1&2&1&0&0&24\\s_2&2&5&3&0&1&0&30\\s_3&0&2&1&0&0&1&16\end{array}$

###### Improving direction

$\begin{array}{c|cccccc|c}\rm{Basis}&x_1&x_2&x_3&s_1&s_2&s_3&\rm{RHS}\\\hline\rm{Row}\space0&\textcolor{red}{-4}&-2&-4&0&0&0&0\\\hline s_1&4&1&2&1&0&0&24\\s_2&2&5&3&0&1&0&30\\s_3&0&2&1&0&0&1&16\end{array}$

###### Entering variables (pivot column)

$x_e=x_1$

##### Step 2. Minimum ratio test

$\begin{array}{c|cccccc|cc}\rm{Basis}&\textcolor{red}{x_1}&x_2&x_3&s_1&s_2&s_3&\rm{RHS}&\rm{radio}\\\hline\rm{Row}\space0&-4&-2&-4&0&0&0&0\\\hline \textcolor{green}{s_1}&\textcolor{blue}{4}&1&2&1&0&0&\textcolor{blue}{24}&\textcolor{green}{24/4=6}\\s_2&\textcolor{blue}{2}&5&3&0&1&0&\textcolor{blue}{30}&30/2=15\\s_3&\textcolor{blue}{0}&2&1&0&0&1&\textcolor{blue}{16}&\rm{N/A}\end{array}$

###### Leaving variable (pivot row)

$x_l=s_1$

##### Step 3. Update solution and basis

$\begin{array}{c|cccccc|c}\rm{Basis}&\textcolor{red}{x_1}&x_2&x_3&s_1&s_2&s_3&\rm{RHS}\\\hline\rm{Row}\space0&\textcolor{red}{-4}&-2&-4&0&0&0&0\\\hline \textcolor{green}{s_1}&\textcolor{red}{4}&\textcolor{green}{1}&\textcolor{green}{2}&\textcolor{green}{1}&\textcolor{green}{0}&\textcolor{green}{0}&\textcolor{green}{24}\\s_2&\textcolor{red}{2}&5&3&0&1&0&30\\s_3&\textcolor{red}{0}&2&1&0&0&1&16\end{array}$

###### New basis

$\begin{array}{c|cccccc|c}\rm{Basis}&x_1&x_2&x_3&s_1&s_2&s_3&\rm{RHS}\\\hline\rm{Row}\space0&0&-1&-2&1&0&0&24\\\hline x_1&\textcolor{red}{1}&1/4&1/2&1/4&\textcolor{red}{0}&\textcolor{red}{0}&6\\s_2&\textcolor{red}{0}&9/2&2&-1/2&\textcolor{red}{1}&\textcolor{red}{0}&18\\s_3&\textcolor{red}{0}&2&1&0&\textcolor{red}{0}&\textcolor{red}{1}&16\end{array}$

#### Iteration 2

##### Step 1. Optimality check

###### Reduced cost

$\begin{array}{c|cccccc|c}\rm{Basis}&x_1&x_2&x_3&s_1&s_2&s_3&\rm{RHS}\\\hline\rm{Row}\space0&0&\textcolor{red}{-1}&\textcolor{red}{-2}&\textcolor{red}{1}&0&0&24\\\hline x_1&1&1/4&1/2&1/4&0&0&6\\s_2&0&9/2&2&-1/2&1&0&18\\s_3&0&2&1&0&0&1&16\end{array}$

###### Improving direction

$\begin{array}{c|cccccc|c}\rm{Basis}&x_1&x_2&x_3&s_1&s_2&s_3&\rm{RHS}\\\hline\rm{Row}\space0&0&-1&\textcolor{red}{-2}&1&0&0&24\\\hline x_1&1&1/4&1/2&1/4&0&0&6\\s_2&0&9/2&2&-1/2&1&0&18\\s_3&0&2&1&0&0&1&16\end{array}$

###### Entering variables (pivot column)

$x_e=x_3$

##### Step 2. Minimum ratio test

$\begin{array}{c|cccccc|cc}\rm{Basis}&x_1&x_2&\textcolor{red}{x_3}&s_1&s_2&s_3&\rm{RHS}&\rm{radio}\\\hline\rm{Row}\space0&0&-1&-2&1&0&0&24\\\hline x_1&1&1/4&\textcolor{blue}{1/2}&1/4&0&0&\textcolor{blue}{6}&6/\left(1/2\right)=12\\\textcolor{green}{s_2}&0&9/2&\textcolor{blue}{2}&-1/2&1&0&\textcolor{blue}{18}&\textcolor{green}{18/2=9}\\s_3&0&2&\textcolor{blue}{1}&0&0&1&\textcolor{blue}{16}&16/1=16\end{array}$

###### Leaving variable (pivot row)

$x_l=s_2$

##### Step 3. Update solution and basis

$\begin{array}{c|cccccc|c}\rm{Basis}&x_1&x_2&\textcolor{red}{x_3}&s_1&s_2&s_3&\rm{RHS}\\\hline\rm{Row}\space0&0&-1&\textcolor{red}{-2}&1&0&0&24\\\hline x_1&1&1/4&\textcolor{red}{1/2}&1/4&0&0&6\\\textcolor{green}{s_2}&\textcolor{green}{0}&\textcolor{green}{9/2}&\textcolor{red}{2}&\textcolor{green}{-1/2}&\textcolor{green}{1}&\textcolor{green}{0}&\textcolor{green}{18}\\s_3&0&2&\textcolor{red}{1}&0&0&1&16\end{array}$

###### New basis

$\begin{array}{c|cccccc|c}\rm{Basis}&x_1&x_2&x_3&s_1&s_2&s_3&\rm{RHS}\\\hline\rm{Row}\space0&0&7/2&0&1/2&1&0&42\\\hline x_1&\textcolor{red}{1}&-7/8&\textcolor{red}{0}&3/8&-1/4&\textcolor{red}{0}&3/2\\x_3&\textcolor{red}{0}&9/4&\textcolor{red}{1}&-1/4&1/2&\textcolor{red}{0}&9\\s_3&\textcolor{red}{0}&-1/4&\textcolor{red}{0}&1/4&-1/2&\textcolor{red}{1}&7\end{array}$

#### Iteration 3

###### Reduced cost

$\begin{array}{c|cccccc|c}\rm{Basis}&x_1&x_2&x_3&s_1&s_2&s_3&\rm{RHS}\\\hline\rm{Row}\space0&0&\textcolor{red}{7/2}&0&\textcolor{red}{1/2}&\textcolor{red}{1}&0&42\\\hline x_1&1&-7/8&0&3/8&-1/4&0&3/2\\x_3&0&9/4&1&-1/4&1/2&0&9\\s_3&0&-1/4&0&1/4&-1/2&1&7\end{array}$

###### No improving directios $\to$ Optimal solution

$\begin{bmatrix}x_1\\x_2\\x_3\end{bmatrix}=\begin{bmatrix}1.5\\0\\9\end{bmatrix},\max\left\{4x_1+2x_2+4x_3\right\}=42$