# Simplex Tableau

$$
\begin{aligned}
\max\quad &4x_1 + 2x_2 + 4x_3 \\
\text{s.t.}\quad &4x_1 + x_2 + 2x_3 \le 24 \\
&2x_1 + 5x_2 + 3x_3 \le 30 \\
&2x_2 + x_3 \le 16 \\
&x_1, x_2, x_3 \ge 0
\end{aligned}
$$

## Add slack variables

Introduce slack variables $s_1,s_2,s_3\ge0$ to obtain equalities:

$$
\begin{aligned}
\max\quad &4x_1 + 2x_2 + 4x_3 \\
\text{s.t.}\quad &4x_1 + x_2 + 2x_3 + s_1 = 24 \\
&2x_1 + 5x_2 + 3x_3 + s_2 = 30 \\
&2x_2 + x_3 + s_3 = 16 \\
&x_1, x_2, x_3, s_1, s_2, s_3 \ge 0
\end{aligned}
$$

## Initialization

| Basis | x1  | x2  | x3  | s1  | s2  | s3  | RHS |
| ----- | --- | --- | --- | --- | --- | --- | --- |
| Row 0 | -4  | -2  | -4  | 0   | 0   | 0   | 0   |
| s1    | 4   | 1   | 2   | 1   | 0   | 0   | 24  |
| s2    | 2   | 5   | 3   | 0   | 1   | 0   | 30  |
| s3    | 0   | 2   | 1   | 0   | 0   | 1   | 16  |

## Iteration 1

### Step 1 — Optimality check

- Reduced cost 
  
  | Basis | x1                          | x2  | x3  | s1  | s2  | s3  | RHS |
  | ----- | --------------------------- | --- | --- | --- | --- | --- | --- |
  | Row 0 | <font color="red">-4</font> | -2  | -4  | 0   | 0   | 0   | 0   |
  | s1    | 4                           | 1   | 2   | 1   | 0   | 0   | 24  |
  | s2    | 2                           | 5   | 3   | 0   | 1   | 0   | 30  |
  | s3    | 0                           | 2   | 1   | 0   | 0   | 1   | 16  |

- Entering variables $x_e=x_1$

### Step 2 — Minimum ratio test

| Basis                         | x1                          | x2  | x3  | s1  | s2  | s3  | RHS |
| ----------------------------- | --------------------------- | --- | --- | --- | --- | --- | --- |
| Row 0                         | <font color="red">-4</font> | -2  | -4  | 0   | 0   | 0   | 0   |
| <font color="green">s1</font> | 4                           | 1   | 2   | 1   | 0   | 0   | 24  |
| s2                            | 2                           | 5   | 3   | 0   | 1   | 0   | 30  |
| s3                            | 0                           | 2   | 1   | 0   | 0   | 1   | 16  |

Leaving variables $x_l=s_1$

### Step 3 — Update solution and basis

| Basis                         | x1                         | x2  | x3  | s1   | s2  | s3  | RHS |
| ----------------------------- | -------------------------- | --- | --- | ---- | --- | --- | --- |
| Row 0                         | <font color="red">0</font> | -1  | -2  | 1    | 0   | 0   | 24  |
| <font color="green">x1</font> | 1                          | 1/4 | 1/2 | 1/4  | 0   | 0   | 6   |
| s2                            | 0                          | 9/2 | 2   | -1/2 | 1   | 0   | 18  |
| s3                            | 0                          | 2   | 1   | 0    | 0   | 1   | 16  |

## Iteration 2

### Step 1 — Optimality check

- Reduced cost 
  
  | Basis | x1  | x2  | x3                          | s1   | s2  | s3  | RHS |
  | ----- | --- | --- | --------------------------- | ---- | --- | --- | --- |
  | Row 0 | 0   | -1  | <font color="red">-2</font> | 1    | 0   | 0   | 24  |
  | x1    | 1   | 1/4 | 1/2                         | 1/4  | 0   | 0   | 6   |
  | s2    | 0   | 9/2 | 2                           | -1/2 | 1   | 0   | 18  |
  | s3    | 0   | 2   | 1                           | 0    | 0   | 1   | 16  |

- Entering variables $x_e=x_3$

### Step 2 — Minimum ratio test

| Basis                         | x1  | x2  | x3                          | s1   | s2  | s3  | RHS |
| ----------------------------- | --- | --- | --------------------------- | ---- | --- | --- | --- |
| Row 0                         | 0   | -1  | <font color="red">-2</font> | 1    | 0   | 0   | 24  |
| x1                            | 1   | 1/4 | 1/2                         | 1/4  | 0   | 0   | 6   |
| <font color="green">s2</font> | 0   | 9/2 | 2                           | -1/2 | 1   | 0   | 18  |
| s3                            | 0   | 2   | 1                           | 0    | 0   | 1   | 16  |

Leaving variables $x_l=s_2$

### Step 3 — Update solution and basis

| Basis                         | x1  | x2   | x3                         | s1   | s2   | s3  | RHS |
| ----------------------------- | --- | ---- | -------------------------- | ---- | ---- | --- | --- |
| Row 0                         | 0   | 7/2  | <font color="red">0</font> | 1/2  | 1    | 0   | 42  |
| x1                            | 1   | -7/8 | 1/2                        | 3/8  | -1/4 | 0   | 3/2 |
| <font color="green">x3</font> | 0   | 9/4  | 1                          | -1/4 | 1/2  | 0   | 9   |
| s3                            | 0   | -1/4 | 0                          | 0    | 1/4  | 1   | 7   |

## Iteration 3

### Step 1 — Optimality check

| Basis | x1  | x2   | x3  | s1   | s2   | s3  | RHS |
| ----- | --- | ---- | --- | ---- | ---- | --- | --- |
| Row 0 | 0   | 7/2  | 0   | 1/2  | 1    | 0   | 42  |
| x1    | 1   | -7/8 | 1/2 | 3/8  | -1/4 | 0   | 3/2 |
| x3    | 0   | 9/4  | 1   | -1/4 | 1/2  | 0   | 9   |
| s3    | 0   | -1/4 | 0   | 0    | 1/4  | 1   | 7   |

No improving direction $\rightarrow$ Optimal solution!

Optimal solution:

$$
x_1 =\frac{3}{2},x_2=0,x_3=9,z=42
$$