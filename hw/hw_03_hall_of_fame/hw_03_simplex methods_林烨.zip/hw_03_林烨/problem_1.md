﻿# Simplex method

$$
\begin{aligned}
\max\quad &4x_1 + 2x_2 + 4x_3 \\
\text{s.t.}\quad &4x_1 + x_2 + 2x_3 \le 24 \\
&2x_1 + 5x_2 + 3x_3 \le 30 \\
&2x_2 + x_3 \le 16 \\
&x_1, x_2, x_3 \ge 0
\end{aligned}
$$

## Add slack variables

Introduce slack variables $s_1,s_2,s_3\ge0$ to obtain equalities:

$$
\begin{aligned}
\max\quad &4x_1 + 2x_2 + 4x_3 \\
\text{s.t.}\quad &4x_1 + x_2 + 2x_3 + s_1 = 24 \\
&2x_1 + 5x_2 + 3x_3 + s_2 = 30 \\
&2x_2 + x_3 + s_3 = 16 \\
&x_1, x_2, x_3, s_1, s_2, s_3 \ge 0
\end{aligned}
$$

## Initialization

Partition variables into basic $x_B=[s_1,s_2,s_3]^T$ and nonbasic $x_N=[x_1,x_2,x_3]^T$.

Objective coefficients:

$$
c_B^T=[0,0,0],\qquad c_N^T=[4,2,4].
$$

Constraint matrices and RHS:

$$
A=\begin{bmatrix}
4 & 1 & 2 & 1 & 0 & 0 \\
2 & 5 & 3 & 0 & 1 & 0 \\
0 & 2 & 1 & 0 & 0 & 1
\end{bmatrix},\qquad
b=\begin{bmatrix}24\\30\\16\end{bmatrix}.
$$

Initial basis and nonbasis (columns of A):

$$
B=I_3=\begin{bmatrix}1 & 0 & 0\\0 & 1 & 0\\0 & 0 & 1\end{bmatrix},\qquad
N=\begin{bmatrix}4 & 1 & 2\\2 & 5 & 3\\0 & 2 & 1\end{bmatrix}.
$$

Initial basic feasible solution:

$$
x=\begin{bmatrix}0\\0\\0\\24\\30\\16\end{bmatrix}
$$

## Iteration 1

### Step 1  Optimality check

With $B=I$, the simplex multipliers are

$$
\pi^T=c_B^TB^{-1}=[0\;0\;0].
$$

Reduced costs:

$$
\bar c_N^T=c_N^T-\pi^TN=[4\;2\;4].
$$

### Step 2  Minimum ratio test

The basic direction for entering column $a_e$ (first column of $N$) is

$$
d_B^{(e)}=-B^{-1}a_e = -a_e = \begin{bmatrix}-4\\-2\\0\end{bmatrix}.
$$

Ratios for components with negative direction are

$$
\frac{24}{4}=6,\qquad \frac{30}{2}=15.
$$

So the step length is $\lambda=6$ (the smallest ratio), and $s_1$ leaves the basis.

### Step 3  Update solution and basis

Update

$$
x^{new}=x+\lambda d = \begin{bmatrix}0\\0\\0\\24\\30\\16\end{bmatrix}+6\begin{bmatrix}1\\0\\0\\-4\\-2\\0\end{bmatrix}=\begin{bmatrix}6\\0\\0\\0\\18\\16\end{bmatrix}.
$$

New basis and nonbasis:

$$
x_B=\begin{bmatrix}x_1\\s_2\\s_3\end{bmatrix}=\begin{bmatrix}6\\18\\16\end{bmatrix},\qquad x_N=\begin{bmatrix}s_1\\x_2\\x_3\end{bmatrix}=\begin{bmatrix}0\\0\\0\end{bmatrix}.
$$

Updated objective coefficients:

$$
c_B^T=[4,0,0],\qquad c_N^T=[0,2,4].
$$

Updated basis and nonbasis matrices 

$$
B=\begin{bmatrix}4 & 0 & 0\\2 & 1 & 0\\0 & 0 & 1\end{bmatrix},\qquad
N=\begin{bmatrix}1 & 1 & 2\\0 & 5 & 3\\0 & 2 & 1\end{bmatrix}.
$$

Inverse of the new basis:

$$
B^{-1}=\begin{bmatrix}\tfrac{1}{4} & 0 & 0\\-\tfrac{1}{2} & 1 & 0\\0 & 0 & 1\end{bmatrix}.
$$

## Iteration 2

### Step 1  Optimality check

$$
\pi^T=c_B^TB^{-1}=[1\;0\;0].
$$

$$
\bar c_N^T=c_N^T-\pi^TN=[-1\;1\;2].
$$

### Step 2  Minimum ratio test ($x_3$ enters)

$$
d_N=\begin{bmatrix}
    0\\0\\1
\end{bmatrix}
$$

$$
a_e=\begin{bmatrix}2\\3\\1\end{bmatrix}
$$

$$
d_B^{(e)}=-B^{-1}a_e = -\begin{bmatrix}\tfrac{1}{2}\\2\\1\end{bmatrix}=\begin{bmatrix}-\tfrac{1}{2}\\-2\\-1\end{bmatrix}.
$$

Compute ratios only for components with $d_j<0$ using current basic values $x_B=[6,18,16]^T$:

$$
\frac{6}{\tfrac{1}{2}}=12,\qquad \frac{18}{2}=9,\qquad \frac{16}{1}=16.
$$

So the step length would be $\lambda=9$, and $s_2$ would leave the basis.

### Step 3  Update solution and basis

Full direction vector (order $[x_1,x_2,x_3,s_1,s_2,s_3]^T$) is

$$
d=\begin{bmatrix}-\tfrac{1}{2}\\0\\1\\0\\-2\\-1\end{bmatrix},
$$

so the updated solution is

$$
x^{new}=x+\lambda d=\begin{bmatrix}6\\0\\0\\0\\18\\16\end{bmatrix}+9\begin{bmatrix}-\tfrac{1}{2}\\0\\1\\0\\-2\\-1\end{bmatrix}=\begin{bmatrix}\tfrac{3}{2}\\0\\9\\0\\0\\7\end{bmatrix}.
$$

New basic and nonbasic variables (after the pivot) are

$$
x_B=\begin{bmatrix}x_1\\x_3\\s_3\end{bmatrix}=\begin{bmatrix}\tfrac{3}{2}\\9\\7\end{bmatrix},\qquad x_N=\begin{bmatrix}s_1\\x_2\\s_2\end{bmatrix}=\begin{bmatrix}0\\0\\0\end{bmatrix}.
$$

Updated objective coefficients:

$$
c_B^T=[4,4,0],\qquad c_N^T=[0,2,0].
$$

Updated basis and nonbasis matrices:

$$
B=\begin{bmatrix}4 & 2 & 0\\2 & 3 & 0\\0 & 1 & 1\end{bmatrix},\qquad
N=\begin{bmatrix}1 & 1 & 0\\0 & 5 & 1\\0 & 2 & 0\end{bmatrix}.
$$

Inverse of the new basis is

$$
B^{-1}=\begin{bmatrix}\tfrac{3}{8} & -\tfrac{1}{4} & 0\\-\tfrac{1}{4} & \tfrac{1}{2} & 0\\\tfrac{1}{4} & -\tfrac{1}{2} & 1\end{bmatrix}.

$$

Recomputing the multipliers and reduced costs confirms optimality: 

$$
\pi^T=c_B^TB^{-1}=[\tfrac{1}{2}\;1\;0],\qquad \bar c_N^T=[-\tfrac{1}{2}\; -\tfrac{7}{2}\; -1].
$$

Therefore the final optimal solution is

$$
x^*=\begin{bmatrix}\tfrac{3}{2}\\0\\9\\0\\0\\7\end{bmatrix},
$$

with objective value

$$
z^*=4\cdot\tfrac{3}{2}+2\cdot0+4\cdot9=6+36=42.
$$