$$
max\quad 4x_1+2x_2+4x_3\\
s.t.\quad 4x_1+x_2+2x_3\le24\\
\quad\quad\quad2x_1+5x_2+3x_3\le30\\
\quad\quad\quad\quad\quad2x_2+x_3\le16\\
\quad\quad\quad\quad\quad x_1,x_2,x_3\ge0
$$

**initialization**

* $$
  c^T_B=[0\quad0\quad 0],c^T_N=[4\quad 2\quad 4]
  $$

  $$
  B=B^{-1}=\begin{bmatrix}1&0&0\\0&1&0\\0&0&1\end{bmatrix},
  N=\begin{bmatrix}4&1&2\\2&5&3\\0&2&1\end{bmatrix},
  b=\begin{bmatrix}24\\30\\16\end{bmatrix}
  $$

* current basic and nonbasic solutions
  $$
  x_B=\begin{bmatrix}s_1\\s_2\\s_3\end{bmatrix}=B^{-1}b=\begin{bmatrix}24\\30\\16\end{bmatrix},
  x_N=\begin{bmatrix}x_1\\x_2\\x_3\end{bmatrix}=0
  $$
  

**iteration 1**

* step 1. reduced cost

$$
\overline c^T_N=c^T_N-c^T_BB^{-1}N\\
=[4\quad2\quad4]-[0\quad0\quad0]\begin{bmatrix}4&1&2\\2&5&3\\0&2&1\end{bmatrix}=[4\quad2\quad4]
$$

​				entering variables			$x_e=x_1$

​				simplex direction 			$d_N=\begin{bmatrix}1\\0\\0\end{bmatrix}$

* step 2. reduced cost

  compute the simplex direction
  $$
  d_B^{(e)}=-B^{-1}a_e=-\begin{bmatrix}1&0&0\\0&1&0\\0&0&1\end{bmatrix}\begin{bmatrix}4\\2\\0\end{bmatrix}=\begin{bmatrix}-4\\-2\\0\end{bmatrix}\\
  $$
  minimum ratio
  $$
  \lambda =min \left\{ \frac{x_j}{-d_j}:d_j<0,j\in B \right\}\\
  =min\left\{ \frac{24}{4},\frac{30}{2} \right\}
  =6.
  $$
  leaving variables		$x_l=s_1$

* step 3. update solution and basis

  update the solution

  $x^{new}=x+\lambda d$
  $$
  \begin{bmatrix}x_1\\x_2\\x_3\\s_1\\s_2\\s_3\end{bmatrix}=\begin{bmatrix}0\\0\\0\\24\\30\\16\end{bmatrix}+6\begin{bmatrix}1\\0\\0\\-4\\-2\\0\end{bmatrix}
  =\begin{bmatrix}6\\0\\0\\0\\18\\16\end{bmatrix}
  $$
  

​				new basic and nonbasic variables
$$
x_B=\begin{bmatrix}x_1\\s_2\\s_3\end{bmatrix}=
\begin{bmatrix}6\\18\\16\end{bmatrix}
,
x_N=\begin{bmatrix}s_1\\x_2\\x_3\end{bmatrix}=
0
$$
​				update the basis
$$
c^T_B=[4\quad0\quad0],c^T_N=[0\quad2\quad4]\\
B=\begin{bmatrix}4&0&0\\2&1&0\\0&0&1\end{bmatrix},
N=\begin{bmatrix} 1&1&2\\0&5&3\\0&2&1\end{bmatrix},
b=\begin{bmatrix}24\\30\\16\end{bmatrix}
$$
$$
B^{-1}=\begin{bmatrix} \frac{1}{4}&0&0\\-\frac{1}{2}&1&0\\0&0&1\end{bmatrix}
$$

**iteration 2**

* step 1. optimality check

  reduced cost
  $$
  \overline c^T_N=c^T_N-c^T_BB^{-1}N\\
  =[0\quad2\quad4]-[4\quad0\quad0]
  \begin{bmatrix} \frac{1}{4}&0&0\\-\frac{1}{2}&1&0\\0&0&1\end{bmatrix}
  \begin{bmatrix} 1&1&2\\0&5&3\\0&2&1\end{bmatrix}
  \\=[-1\quad1\quad2]
  $$
  entering variables  $x_e=x_3$

  simplex direction $d_N=\begin{bmatrix}0\\0\\1\end{bmatrix}$

* step 2.minimum ratio test

  compute the simplex direction
  $$
  d_B^{(e)}=-B^{-1}a_e=-
  \begin{bmatrix} \frac{1}{4}&0&0\\-\frac{1}{2}&1&0\\0&0&1\end{bmatrix}
  \begin{bmatrix}2\\3\\1\end{bmatrix}=\begin{bmatrix}
  -\frac{1}{2}\\-2\\-1\end {bmatrix}
  $$
  minimum ratio
  $$
  \lambda==min \left\{ \frac{x_j}{-d_j}:d_j<0,j\in B \right\}\\
  =min\left\{ 12,9,16 \right\}
  =9
  $$
  leaving variables $x_l=s_2$

* step 3.update solution and basis

  update the solution

  $x^{new}=x+\lambda d$
  $$
  \begin{bmatrix}x_1\\x_2\\x_3\\s_1\\s_2\\s_3\end{bmatrix}
  =\begin{bmatrix}6\\0\\0\\0\\18\\16\end{bmatrix}+
  9\begin{bmatrix}-\frac{1}{2} \\0\\1\\0\\-2\\-1\end{bmatrix}
  =\begin{bmatrix}\frac{3}{2}\\0\\9\\0\\0\\7\end {bmatrix}
  $$
  new basic and nonbasic variables
  $$
  x_B=\begin{bmatrix}x_1\\x_3\\s_3\end{bmatrix}=
  \begin{bmatrix}\frac{3}{2}\\9\\7\end{bmatrix}
  ,
  x_N=\begin{bmatrix}s_1\\x_2\\s_2\end{bmatrix}=
  0
  $$
  update the basis
  $$
  c^T_B=[4\quad4\quad0],c^T_N=[0\quad2\quad0]\\
  B=\begin{bmatrix}4&2&0\\2&3&0\\0&1&1\end{bmatrix},
  N=\begin{bmatrix} 1&1&0\\0&5&1\\0&2&0\end{bmatrix},
  b=\begin{bmatrix}24\\30\\16\end{bmatrix}
  $$

  $$
  B^{-1}=\begin{bmatrix}\frac{3}{8}&-\frac{1}{4}&0\\
  -\frac{1}{4}&\frac{1}{2}&0\\
  \frac{1}{4}&-\frac{1}{2}&1
  \end{bmatrix}
  $$

  

**iteration 3**

* step 1.optimality check

  reduced cost
  $$
  \overline c^T_N=c^T_N-c^T_BB^{-1}N\\
  =[0\quad2\quad0]-[4\quad4\quad0]\begin{bmatrix}\frac{3}{8}&-\frac{1}{4}&0\\
  -\frac{1}{4}&\frac{1}{2}&0\\
  \frac{1}{4}&-\frac{1}{2}&1
  \end{bmatrix}
  \begin{bmatrix} 1&1&0\\0&5&1\\0&2&0\end{bmatrix}\\
  =	[-\frac{1}{2}\quad -\frac{9}{2}\quad -1]
  $$
  no improving directions

  so this is the optimal solution
  $$
  x^T=[x_1\quad x_2\quad x_3]=[\frac{3}{2}\quad 0 \quad 9]
  \\
  Z=4x_1+2x_2+4x_3=42
  $$
  