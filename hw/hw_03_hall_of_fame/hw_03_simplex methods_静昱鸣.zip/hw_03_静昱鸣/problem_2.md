## 问题与标准形

原问题  
$$
\max\ z \;=\; 4x_1+2x_2+4x_3
$$
约束
$$
\begin{aligned}
4x_1+x_2+2x_3 &\le 24,\\
2x_1+5x_2+3x_3 &\le 30,\\
2x_2+x_3 &\le 16,\\
x_1,x_2,x_3 &\ge 0.
\end{aligned}
$$

加松弛变量 $s_1,s_2,s_3\ge 0$
$$
\begin{aligned}
4x_1 &+ 1x_2  &+ 2x_3 &+ s_1 &      &      &= 24,\\
2x_1 &+ 5x_2  &+ 3x_3 &      &+ s_2 &      &= 30,\\
     &+ 2x_2  &+ 1x_3 &      &      &+ s_3 &= 16.
\end{aligned}
$$

# Prob 2. using Algorithm 3

### Step 0. 初始增广表

$$
\begin{array}{c|rrrrrr|r}
 & x_1&x_2&x_3&s_1&s_2&s_3&\text{RHS}\\\hline
\text{row 0} & -4 & -2 & -4 & 0 & 0 & 0 & 0\\
\text{row 1} & 4 & 1 & 2 & 1 & 0 & 0 & 24\\
\text{row 2} & 2 & 5 & 3 & 0 & 1 & 0 & 30\\
\text{row 3} & 0 & 2 & 1 & 0 & 0 & 1 & 16\\
\end{array}
$$

---

### **Step 1**

**选入基列**：最负（并列）的是 $-4$，取 **$x_1$​** 列为枢轴列 (pivot)。

<table style="border-collapse:collapse;font-family:'Times New Roman',serif;font-size:16px;text-align:center;">
  <thead style="background:#f2f2f2;">
    <tr>
      <th style="border:1px solid #444;padding:4px;"></th>
      <th style="border:1px solid #444;padding:4px;">x₁</th>
      <th style="border:1px solid #444;padding:4px;">x₂</th>
      <th style="border:1px solid #444;padding:4px;">x₃</th>
      <th style="border:1px solid #444;padding:4px;">s₁</th>
      <th style="border:1px solid #444;padding:4px;">s₂</th>
      <th style="border:1px solid #444;padding:4px;">s₃</th>
      <th style="border:1px solid #444;padding:4px;">RHS</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="border:1px solid #444;padding:4px;">row&nbsp;0</td>
      <td style="border:1px solid #444;padding:4px;background:#fff3b0;">−4</td>
      <td style="border:1px solid #444;padding:4px;">−2</td>
      <td style="border:1px solid #444;padding:4px;">−4</td>
      <td style="border:1px solid #444;padding:4px;">0</td>
      <td style="border:1px solid #444;padding:4px;">0</td>
      <td style="border:1px solid #444;padding:4px;">0</td>
      <td style="border:1px solid #444;padding:4px;">0</td>
    </tr>
    <tr>
      <td style="border:1px solid #444;padding:4px;">row&nbsp;1</td>
      <td style="border:1px solid #444;padding:4px;color:#b30000;">4</td>
      <td style="border:1px solid #444;padding:4px;">1</td>
      <td style="border:1px solid #444;padding:4px;">2</td>
      <td style="border:1px solid #444;padding:4px;">1</td>
      <td style="border:1px solid #444;padding:4px;">0</td>
      <td style="border:1px solid #444;padding:4px;">0</td>
      <td style="border:1px solid #444;padding:4px;color:#b30000;">24</td>
    </tr>
    <tr>
      <td style="border:1px solid #444;padding:4px;">row&nbsp;2</td>
      <td style="border:1px solid #444;padding:4px;color:#b30000;">2</td>
      <td style="border:1px solid #444;padding:4px;">5</td>
      <td style="border:1px solid #444;padding:4px;">3</td>
      <td style="border:1px solid #444;padding:4px;">0</td>
      <td style="border:1px solid #444;padding:4px;">1</td>
      <td style="border:1px solid #444;padding:4px;">0</td>
      <td style="border:1px solid #444;padding:4px;color:#b30000;">30</td>
    </tr>
    <tr>
      <td style="border:1px solid #444;padding:4px;">row&nbsp;3</td>
      <td style="border:1px solid #444;padding:4px;color:#b30000;">0</td>
      <td style="border:1px solid #444;padding:4px;">2</td>
      <td style="border:1px solid #444;padding:4px;">1</td>
      <td style="border:1px solid #444;padding:4px;">0</td>
      <td style="border:1px solid #444;padding:4px;">0</td>
      <td style="border:1px solid #444;padding:4px;">1</td>
      <td style="border:1px solid #444;padding:4px;color:#b30000;">16</td>
    </tr>
  </tbody>
</table>

最小比值检验：

- 行 1：比值 $24/4=6$
- 行 2：比值 $30/2=15$
- 行 3：系数为 0，过
  最小为 6，于`row1`取得。  

---

### **行变换**

1) 把 row1 枢轴元化为 1：

$$
\begin{array}{c|rrrrrr|r}
 & x_1&x_2&x_3&s_1&s_2&s_3&\text{RHS}\\\hline
\text{row 0} & -4 & -2 & -4 & 0 & 0 & 0 & 0\\
\text{row 1} & 1 & \tfrac14 & \tfrac12 & \tfrac14 & 0 & 0 & 6\\
\text{row 2} & 2 & 5 & 3 & 0 & 1 & 0 & 30\\
\text{row 3} & 0 & 2 & 1 & 0 & 0 & 1 & 16\\
\end{array}
$$

2. 把同列其它元素消为 0：

$$
\begin{array}{c|rrrrrr|r}
 & x_1&x_2&x_3&s_1&s_2&s_3&\text{RHS}\\\hline
\text{row 0} & 0 & -1 & -2 & 1 & 0 & 0 & 24\\
\text{row 1} & 1 & \tfrac14 & \tfrac12 & \tfrac14 & 0 & 0 & 6\\
\text{row 2} & 0 & \tfrac{9}{2} & 2 & -\tfrac12 & 1 & 0 & 18\\
\text{row 3} & 0 & 2 & 1 & 0 & 0 & 1 & 16\\
\end{array}
$$

---

### **Step 2**

第 0 行最负的是 $-2$（位于 $x_3$ 列）。故 **入基列 $x_3$​**。

<table border="1" cellspacing="0" cellpadding="6" style="border-collapse:collapse; text-align:center; font-family:Times New Roman, serif;">
  <tr>
    <th></th>
    <th>x₁</th>
    <th>x₂</th>
    <th>x₃</th>
    <th>s₁</th>
    <th>s₂</th>
    <th>s₃</th>
    <th>RHS</th>
  </tr>
  <tr>
    <td><b>row 0</b></td>
    <td>0</td>
    <td>−1</td>
    <td style="background-color:#fff3b0;">−2</td>
    <td>1</td>
    <td>0</td>
    <td>0</td>
    <td>24</td>
  </tr>
  <tr>
    <td><b>row 1</b></td>
    <td>1</td>
    <td>¼</td>
    <td style="color:#cc0000;">½</td>
    <td>¼</td>
    <td>0</td>
    <td>0</td>
    <td style="color:#cc0000;">6</td>
  </tr>
  <tr>
    <td><b>row 2</b></td>
    <td>0</td>
    <td>9/2</td>
    <td style="color:#cc0000;">2</td>
    <td>−½</td>
    <td>1</td>
    <td>0</td>
    <td style="color:#cc0000;">18</td>
  </tr>
  <tr>
    <td><b>row 3</b></td>
    <td>0</td>
    <td>2</td>
    <td style="color:#cc0000;">1</td>
    <td>0</td>
    <td>0</td>
    <td>1</td>
    <td style="color:#cc0000;">16</td>
  </tr>
</table>


最小比值检验：

- 行 1：比值 $6\,/\,(\tfrac12)=12$；
- 行 2：比值 $18\,/\,2=9$；
- 行 3：比值 $16\,/\,1=16$。
  最小为 9，于 `row 2` 取得

---

### **行变换**

1) 枢轴元化 1：

$$
\begin{array}{c|rrrrrr|r}
 & x_1&x_2&x_3&s_1&s_2&s_3&\text{RHS}\\\hline
\text{row 0} & 0 & -1 & -2 & 1 & 0 & 0 & 24\\
\text{row 1} & 1 & \tfrac14 & \tfrac12 & \tfrac14 & 0 & 0 & 6\\
\text{row 2} & 0 & \tfrac{9}{4} & 1 & -\tfrac14 & \tfrac12 & 0 & 9\\
\text{row 3} & 0 & 2 & 1 & 0 & 0 & 1 & 16\\
\end{array}
$$

2. 同列消 0：

$$
\begin{array}{c|rrrrrr|r}
 & x_1&x_2&x_3&s_1&s_2&s_3&\text{RHS}\\\hline
\text{row 0} & 0 & \tfrac72 & 0 & \tfrac12 & 1 & 0 & 42\\
\text{row 1} & 1 & -\tfrac78 & 0 & \tfrac38 & -\tfrac14 & 0 & \tfrac32\\
\text{row 2} & 0 & \tfrac94 & 1 & -\tfrac14 & \tfrac12 & 0 & 9\\
\text{row 3} & 0 & -\tfrac14 & 0 & \tfrac14 & -\tfrac12 & 1 & 7\\
\end{array}
$$

第 0 行已无负项，**最优**。

读出最优解：

- $x_1$ 列是单位列，row 1 RHS $=\tfrac32\Rightarrow x_1=\tfrac32$；
- $x_3$ 列是单位列，row 2 RHS $=9\Rightarrow x_3=9$；
- $s_3$ 列是单位列，row 3 RHS $=7\Rightarrow s_3=7$；
- 其他非基变量 $x_2=s_1=s_2=0$。
- 目标值在 row 0 的 RHS：$z=42$。

---

## 综上述：

$$
\boxed{
x_1=\tfrac32=1.5,\quad x_2=0,\quad x_3=9,\quad
z^*=42
}
$$

且 $(s_1,s_2,s_3)=(0,0,7)$。  