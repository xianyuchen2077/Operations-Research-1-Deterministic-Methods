## 问题与标准形

原问题  
$$
\max\ z \;=\; 4x_1+2x_2+4x_3
$$
约束
$$
\begin{aligned}
4x_1+x_2+2x_3 &\le 24,\\
2x_1+5x_2+3x_3 &\le 30,\\
2x_2+x_3 &\le 16,\\
x_1,x_2,x_3 &\ge 0.
\end{aligned}
$$

加松弛变量 $s_1,s_2,s_3\ge 0$
$$
\begin{aligned}
4x_1 &+ 1x_2  &+ 2x_3 &+ s_1 &      &      &= 24,\\
2x_1 &+ 5x_2  &+ 3x_3 &      &+ s_2 &      &= 30,\\
     &+ 2x_2  &+ 1x_3 &      &      &+ s_3 &= 16.
\end{aligned}
$$

令
$$
\bar x=(x_1,x_2,x_3,s_1,s_2,s_3)^\top,\quad 
\bar c=(4,2,4,0,0,0)^\top,\quad 
b=(24,30,16)^\top.
$$
设各列向量：
$$
\begin{aligned}
a_1&=(4,2,0)^\top,\quad
a_2=(1,5,2)^\top,\quad
a_3=(2,3,1)^\top,\\
a_{s_1}&=(1,0,0)^\top,\quad
a_{s_2}=(0,1,0)^\top,\quad
a_{s_3}=(0,0,1)^\top.
\end{aligned}
$$

---

# Prob 1. Solve the linear program below using Algorithm 2.

### Step 0. 初始化
初始基变量集合 $B=\{s_1,s_2,s_3\}$，非基集合 $N=\{x_1,x_2,x_3\}$。

- 初始基矩阵 $B=[a_{s_1},a_{s_2},a_{s_3}]=I_3$，故 $B^{-1}=I_3$。
- 基变量取值 $x_B=b=(24,30,16)^\top$。
- 初始解 $\bar x=(0,0,0,24,30,16)$。
- 目标值 $z=\bar c^\top \bar x=0$。

---

### **迭代 1**

#### Step 1. 最优性检验
- $c_B=(0,0,0)^\top$
- $\pi^\top$：
  $$
  \pi^\top=c_B^\top B^{-1}=(0,0,0).
  $$
- reduced cost ：
  $$
  \bar c_N^\top=c_N^\top-\pi^\top N=c_N^\top=(4,2,4).
  $$
  存在并列最大 $\bar c=4$（$x_1$ 与 $x_3$）。  
  不妨取 **$x_1$** 为进入变量（$x_e=x_1$）。

#### Step 2. 方向&步长
- 方向：
  $$
  d_B^{(e)}=-B^{-1}a_e=-I_3\,a_1=-a_1=(-4,-2,0)^\top.
  $$
  记 $d=d_B^{(e)}=(-4,-2,0)^\top$。
- 因为 $d$ 并非全 $\ge 0$，问题不无界。  
  步长：
  $$
  \lambda=\min\left\{\frac{x_{B,j}}{-d_j}:d_j<0\right\}
  =\min\left\{\frac{24}{4},\frac{30}{2}\right\}
  =\min\{6,15\}=6.
  $$
  故离开变量 $l=s_1$。

#### Step 3. 更新解与基
$$
x_B^{\text{new}}=x_B+\lambda d=(24,30,16)+6(-4,-2,0)=(0,18,16).
$$
- 进入变量的值：$x_1^{\text{new}}=\lambda=6$。

- 换基：用 $x_1$ 替换 $s_1$。  
  新的基集合 $B=\{x_1,s_2,s_3\}$：
  $$
  x_B=(x_1,s_2,s_3)=(6,18,16).
  $$

- 新基矩阵与其逆：  
  $$
  B=[a_{x_1},a_{s_2},a_{s_3}]=
  \begin{bmatrix}
  4&0&0\\
  2&1&0\\
  0&0&1
  \end{bmatrix}.
  $$
  计算 $B^{-1}$得：
  $$
  B^{-1}=
  \begin{bmatrix}
  \tfrac14&0&0\\[2pt]
  -\tfrac12&1&0\\[2pt]
  0&0&1
  \end{bmatrix}.
  $$
  新目标值：$z=4\cdot 6=24$。

---

### **迭代 2**

#### Step 1. 
- $c_B=(4,0,0)^\top$（$x_1,s_2,s_3$)
  $$
  \pi^\top=c_B^\top B^{-1}=(4,0,0)
  \begin{bmatrix}
  \tfrac14&0&0\\[2pt]
  -\tfrac12&1&0\\[2pt]
  0&0&1
  \end{bmatrix}
  =(1,0,0).
  $$

- 此时 $N=\{x_2,x_3,s_1\}$。
  $$
  \begin{aligned}
  \bar c_{x_2}&=2-\pi^\top a_2=2-(1,0,0)\!\cdot\!(1,5,2)=2-1=1,\\
  \bar c_{x_3}&=4-\pi^\top a_3=4-(1,0,0)\!\cdot\!(2,3,1)=4-2=2,\\
  \bar c_{s_1}&=0-\pi^\top a_{s_1}=0-(1,0,0)\!\cdot\!(1,0,0)=0-1=-1.
  \end{aligned}
  $$
  最大的是 $\bar c_{x_3}=2$。  
  选入基变量：$x_e=x_3$。

#### Step 2. 
- $d_B^{(e)}=-B^{-1}a_{x_3}$：
  $$
  -B^{-1}a_3=
  -\begin{bmatrix}
  \tfrac14&0&0\\[2pt]
  -\tfrac12&1&0\\[2pt]
  0&0&1
  \end{bmatrix}
  \!\!\begin{bmatrix}2\\3\\1\end{bmatrix}
  =
  -\begin{bmatrix}
  \tfrac14\cdot 2+0\cdot 3+0\cdot 1\\[4pt]
  -\tfrac12\cdot 2+1\cdot 3+0\cdot 1\\[4pt]
  0\cdot 2+0\cdot 3+1\cdot 1
  \end{bmatrix}
  =-
  \begin{bmatrix}
  \tfrac12\\[2pt]
  2\\[2pt]
  1
  \end{bmatrix}.
  $$
  步长：
  $$
  \begin{aligned}
  \frac{x_{x_1}}{-d_1}&=\frac{6}{1/2}=12,\\
  \frac{x_{s_2}}{-d_2}&=\frac{18}{2}=9,\\
  \frac{x_{s_3}}{-d_3}&=\frac{16}{1}=16.
  \end{aligned}
  $$
  min 为 $9$，故 $l=s_2$，步长 $\lambda=9$。

#### Step 3. 
-  $(x_1,s_2,s_3)$ 更新：
  $$
  x_B^{\text{new}}=x_B+\lambda d=(6,18,16)+9\!\left(-\tfrac12,-2,-1\right)
  =\left(6-\tfrac{9}{2},\,18-18,\,16-9\right)
  =\left(\tfrac32,\,0,\,7\right).
  $$
- 进入 $x_3^{\text{new}}=\lambda=9$。
- 新基 $B=\{x_1,x_3,s_3\}$，此时 $N=\{x_2,s_1,s_2\}$。
  $$
  (x_1,x_3,s_3)=\left(\tfrac32,\,9,\,7\right).
  $$
- 新基矩阵与逆： 
  $$
  B=[a_{x_1},a_{x_3},a_{s_3}]=
  \begin{bmatrix}
  4&2&0\\
  2&3&0\\
  0&1&1
  \end{bmatrix}.
  $$
  解 $B^{-1}$得：
  $$
  B^{-1}=
  \begin{bmatrix}
  \tfrac38&-\tfrac14&0\\[2pt]
  -\tfrac14&\tfrac12&0\\[2pt]
  \tfrac14&-\tfrac12&1
  \end{bmatrix}.
  $$
- 此时 $c_B=(4,4,0)^\top$，
  $$
  \pi^\top=c_B^\top B^{-1}=(4,4,0)
  \begin{bmatrix}
  \tfrac38&-\tfrac14&0\\
  -\tfrac14&\tfrac12&0\\
  \tfrac14&-\tfrac12&1
  \end{bmatrix}
  =( \tfrac12,\,1,\,0).
  $$
  而：
  $$
  \begin{aligned}
  \bar c_{x_2}&=2-\pi^\top a_2
  =2-(\tfrac12,1,0)\!\cdot\!(1,5,2)
  =-3.5,\\
  \bar c_{s_1}&=0-\pi^\top a_{s_1}
  =0-(\tfrac12,1,0)\!\cdot\!(1,0,0)=-\tfrac12,\\
  \bar c_{s_2}&=0-\pi^\top a_{s_2}
  =0-(\tfrac12,1,0)\!\cdot\!(0,1,0)=-1.
  \end{aligned}
  $$
  全部 $\le 0$，**达到最优**。

#### 结论
$$
x_1=\tfrac32,\quad x_2=0,\quad x_3=9,\quad
s_1=0,\ s_2=0,\ s_3=7,
$$
$$
z^*=4\cdot\tfrac32+2\cdot 0+4\cdot 9=42.
$$
约束校验：
- $4(1.5)+0+2(9)=6+18=24\Rightarrow s_1=0$；
- $2(1.5)+5(0)+3(9)=3+27=30\Rightarrow s_2=0$；
- $2(0)+9=9\le 16\Rightarrow s_3=7$。
